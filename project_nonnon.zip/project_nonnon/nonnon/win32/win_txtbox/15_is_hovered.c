// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




bool
n_win_txtbox_is_hovered( n_win_txtbox *p )
{

	if ( p == NULL ) { return false; }

	if ( false == IsWindow       ( p->hwnd ) ) { return false; }
	if ( false == IsWindowVisible( p->hwnd ) ) { return false; }


	bool is_hovered;

	p->hover_cch_x = 0;

	{

		s32 sx,sy; n_win_size( p->hwnd, &sx, &sy );

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= GetSystemMetrics( SM_CYHSCROLL ); }
		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= GetSystemMetrics( SM_CXVSCROLL ); }

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			sx -= p->pad_pxl_sx * 2;
		} else {
			sx -= p->pad_pxl_sx * 2;
			sy -= p->pad_pxl_sy * 2;
		}

		is_hovered = n_win_is_hovered_offset( p->hwnd, 0,0,sx,sy );

	}


	// [!] : fail-safe

	if ( p->cell_pxl_sy <= 0 ) { return is_hovered; }


	// [!] : N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL : out-of-bound area is acceptable for usability

	s32 x,y; n_win_cursor_position_relative( p->hwnd, &x, &y );

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{

		p->hover_cch_y = 0;

	} else {

		// [!] : -1 means "all lines"

		s32 o = ( y - p->pad_pxl_sy ) / p->cell_pxl_sy;

		if ( o <= -1 )
		{
			p->hover_cch_y = n_posix_max_s32( 0, p->hover_cch_y + o );
			if ( p->scroll_cch_tabbed_y == 0 )
			{
				p->hover_under = o;
			} else {
				p->hover_under = 0;
			}
		} else {
			p->hover_cch_y = p->scroll_cch_tabbed_y + o;
			p->hover_under = 0;
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{
			if ( false == p->is_dragging )
			{
				s32 sy = p->scroll_cch_tabbed_y + ( ( p->canvas_pxl_sy - p->pad_pxl_sy ) / p->cell_pxl_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", sy, p->hover_cch_y );
				if ( sy <= p->hover_cch_y ) { p->hover_cch_y = sy; return false; }
			}
		}
	}


	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { return is_hovered; }
//return is_hovered;

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->hover_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", ( p->hover_cch_y >= p->txt.sy ) );

	// [!] : Notepad compatible behavior

	if ( (u32) p->hover_cch_y <          0 ) { return is_hovered; }
	if ( (u32) p->hover_cch_y >= p->txt.sy ) { p->hover_cch_y = p->txt.sy - 1; }


	s32 nc_sx = p->pad_pxl_sx;
	s32 nc_sy = p->pad_pxl_sy;

	if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
	{
		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ) { nc_sx += n_win_txtbox_horizontal_centering( p ); }
		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) { nc_sx += p->number_pxl_sx + p->number_pad_pxl_sx; }
	}

	// [!] : for usability

	p->is_hovered_linenum = false;

	if ( is_hovered )
	{
		s32 pad_fx = 0;
		s32 pad_tx = nc_sx;

		if ( ( x >= pad_fx )&&( x <= pad_tx ) )
		{
//n_posix_debug_literal( " ! " );
			p->hover_cch_x = 0;

			if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			{
				p->is_hovered_linenum = true;
			}

			return true;
		}

	}


	// [Needed] : for press'n'run

	if ( x < nc_sx ) { return false; }


	p->hdc = GetDC( p->hwnd );


	HFONT hf = SelectObject( p->hdc, n_win_font_get( p->hwnd ) );


	n_posix_char *text = n_txt_get( &p->txt, p->hover_cch_y );


	SIZE  size  = { 0,0 };
	s32   cch   = 0;
	s32   tab   = 0;

	s32   osx    = p->scroll_pxl_tabbed_x;
	//s32   osy    = p->scroll_cch_tabbed_y * p->cell_pxl_sy;
	s32   draw_x = nc_sx - osx;
	s32   text_x = 0;
	POINT cursor = { x, nc_sy + ( y / p->cell_pxl_sy * p->cell_pxl_sy ) };
	while( 1 )
	{//break;

		n_posix_char *character = n_win_txtbox_character( p, text, text_x, &size, &cch, &tab );


		s32 inc = n_string_doublebyte_increment( text[ text_x ] );
		if (
			( n_unicode_surrogatepair_is_hi( character[ 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( character[ 1 ] ) )
		)
		{
			inc = 2;
		}

		RECT rect; n_win_rect_set( &rect, draw_x, cursor.y, size.cx, p->cell_pxl_sy );

		if ( n_string_is_empty( character ) )
		{

			p->hover_cch_x = text_x;

			break;

		} else
		if ( PtInRect( &rect, cursor ) )
		{

			s32 half_sx = ( size.cx / 2 );

			n_win_rect_set( &rect, draw_x + half_sx, cursor.y, half_sx, p->cell_pxl_sy );

			if ( PtInRect( &rect, cursor ) ) { text_x += inc; }


			p->hover_cch_x = text_x;


			break;

		}

		draw_x += size.cx;
		text_x += inc;

	}


	SelectObject( p->hdc, hf );
	ReleaseDC( p->hwnd, p->hdc );
	p->hdc = NULL;


	return is_hovered;
}


