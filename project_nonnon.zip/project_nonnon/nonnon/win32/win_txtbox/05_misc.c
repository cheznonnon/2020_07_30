// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_fade_go( n_win_txtbox *p, COLORREF color )
{

	// [!] : for IME fade


	if ( p == NULL ) { return; }


	n_bmp_fade_go( &p->fade, color );

	if ( p->fade_timer == 0 ) { p->fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( p->hwnd, p->fade_timer, 33 );


	return;
}

void
n_win_txtbox_oneline_fade_out( n_win_txtbox *p )
{

	// [!] : for ONELINE fade


	if ( p == NULL ) { return; }


	if ( false == ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FADEOUT ) ) { return; }


//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->fade_vk, p->fade_is_selected );

	if (
		( p->fade_vk == 0x08 )
		&&
		( p->fade_is_selected == false )
	)
	{
		return;
	}


	u32 color_bg;
	u32 color_fg;

	if ( p->hwnd == GetFocus() )
	{
		color_bg = p->color_back_noselect;
		color_fg = p->color_back_selected;
	} else {
		color_bg = n_bmp_white;
		color_fg = n_bmp_black;
	}

	n_bmp_fade_init( &p->fade, color_bg );
	n_bmp_fade_go  ( &p->fade, color_fg );


	if ( p->fade_timer == 0 ) { p->fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( p->hwnd, p->fade_timer, 33 );


	return;
}

void
n_win_txtbox_on_setcursor( n_win_txtbox *p )
{

	// [x] : static ownerdraw and disabled controls are excluded;

	HWND hwnd = NULL;
/*
	if ( hwnd != NULL )
	{
		if ( p->hwnd != n_win_cursor2hwnd_relative( GetParent( p->hwnd ) ) )
		{
			n_win_cursor_add( hwnd, IDC_ARROW );
			return;
		}
	}
*/
	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
	{

		n_win_cursor_add( hwnd, IDC_ARROW );

	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM )
	{

		n_win_cursor_add( hwnd, IDC_ARROW );
/*
		// [!] : no ibeam when normal, ibeam when IME is ON

		extern bool n_win_txtbox_is_hovered( n_win_txtbox* );

		if (
			( p->ime_onoff )
			&&
			( p->menu_onoff == false )
			&&
			( p->is_hovered_linenum == false )
			&&
			( n_win_txtbox_is_hovered( p ) )
			&&
			( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
		)
		{
			n_win_cursor_add( hwnd, IDC_IBEAM );
		} else {
			n_win_cursor_add( hwnd, IDC_ARROW );
		}
*/
	} else {
//n_win_txtbox_hwndprintf_literal( p, " 0 " );
//n_win_cursor_add( hwnd, IDC_IBEAM ); return;

		extern bool n_win_txtbox_is_hovered( n_win_txtbox* );

		bool is_hovered = n_win_txtbox_is_hovered( p );

		if ( p->menu_onoff )
		{

			n_win_cursor_add( hwnd, IDC_ARROW );

		} else
		if ( is_hovered == false )
		{

			n_win_cursor_add( hwnd, IDC_ARROW );

		} else {

			if (
				( p->smallbutton_margin == 0 )
				||
				( false == IsWindowVisible( n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				n_win_cursor_add( hwnd, IDC_IBEAM );
			} else

			if (
				( p->menu_onoff         == false )
				&&
				( p->is_hovered_linenum == false )
				&&
				( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				n_win_cursor_add( hwnd, IDC_IBEAM );
			}

		}

	}


	return;
}

void
n_win_txtbox_grayed( n_win_txtbox *p, bool onoff )
{

	if ( p == NULL ) { return; }


	if ( onoff )
	{
		p->color_back_noselect = p->color_back_disabled;
	} else {
		p->color_back_noselect = p->color_back__enabled;
	}

	n_win_txtbox_refresh( p );


	return;
}

void
n_win_txtbox_caret_onoff( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->caret_onoff = true;


	return;
}

bool
n_win_txtbox_is_caret_tail( n_win_txtbox *p )
{
	return (
		( ( p->shift_dragging == VK_RIGHT )||( p->shift_dragging == VK_DOWN ) )
		||
		( ( p->prv_drag       == VK_RIGHT )||( p->prv_drag       == VK_DOWN ) )
	);
}

void
n_win_txtbox_scaling( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->scale = n_win_dpi( p->hwnd ) / 96;


	return;
}

// internal
s32
n_win_txtbox_horizontal_centering( n_win_txtbox *p )
{

	s32 ret = 0;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER )
	)
	{
		n_posix_char *text = n_txt_get( &p->txt, 0 );

		SIZE size = n_win_txtbox_size_text( p, text );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			ret = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}

		n_win_txtbox_caret_onoff( p );
	}


	return ret;
}


