// Nonnon COM : DWebBrowserEvents2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// [x] : MinGW : many symbols are missing
//
//	please search them
//	some patches are written in nonnon/com/com/patch.c




#ifndef _H_NONNON_WIN32_COM_DWEBBROWSEREVENTS2
#define _H_NONNON_WIN32_COM_DWEBBROWSEREVENTS2




#include "com.c"




HRESULT __stdcall
n_DWebBrowserEvents2_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
N_COM_DEBUG_LISTBOX_SET_A( "DWebBrowserEvents2_IUnknown_QueryInterface" );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID w = n_com_guid( n_guid_DIID_DWebBrowserEvents2 );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
		||
		( IsEqualGUID( iid, &w ) )
	)
	{
//n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}

#define DISPID_BEFORENAVIGATE 100

typedef enum BrowserBeforeNavConstants {

	beforeNavigateExternalFrameTarget = 0x1

} BrowserBeforeNavConstants;

#define DISPID_BEFORENAVIGATE2 250
void
BeforeNavigate2
(
	IDispatch    *pDisp,
	VARIANT      *url,
	VARIANT      *Flags,
	VARIANT      *TargetFrameName,
	VARIANT      *PostData,
	VARIANT      *Headers,
	VARIANT_BOOL *Cancel
) 
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : BeforeNavigate2" );


	// [Mechanism]
	//
	//	V_BSTR( url )
	//	V_I4( Flags ) == beforeNavigateExternalFrameTarget
	//	V_BSTR( TargetFrameName )
	//	V_BSTR( Headers )
	//	(*Cancel) = VARIANT_TRUE;

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( url ) );
N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( TargetFrameName ) );
N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( Headers ) );


	return;
}

#define DISPID_CLIENTTOHOSTWINDOW 268
void
ClientToHostWindow( long *CX, long *CY )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : ClientToHostWindow" );


	return;
}

typedef enum CommandStateChangeConstants {

	CSC_UPDATECOMMANDS  = (int) 0xFFFFFFFF,
	CSC_NAVIGATEFORWARD = 0x1,
	CSC_NAVIGATEBACK    = 0x2

} CommandStateChangeConstants;

#define DISPID_COMMANDSTATECHANGE 105
void
CommandStateChange( long Command, VARIANT_BOOL Enable )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : CommandStateChange" );

	switch( Command ) {

	case CSC_UPDATECOMMANDS :

N_COM_DEBUG_LISTBOX_SET_A( "CSC_UPDATECOMMANDS" );

	break;

	case CSC_NAVIGATEFORWARD :

N_COM_DEBUG_LISTBOX_SET_A( "CSC_NAVIGATEFORWARD" );

	break;

	case CSC_NAVIGATEBACK :

N_COM_DEBUG_LISTBOX_SET_A( "CSC_NAVIGATEBACK" );

	break;

	}//switch


	return;
}

#define DISPID_DOCUMENTCOMPLETE 259
void
DocumentComplete( IDispatch *pDisp, VARIANT *URL )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : DocumentComplete" );

	//V_BSTR( url )

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( URL ) );


	return;
}

#define DISPID_DOWNLOADBEGIN 106
void
DownloadBegin( VOID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : DownloadBegin" );


	return;
}

#define DISPID_DOWNLOADCOMPLETE 104
void
DownloadComplete( VOID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : DownloadComplete" );


	return;
}

#define DISPID_FILEDOWNLOAD 270
void
FileDownload( VARIANT_BOOL *ActiveDocument, VARIANT_BOOL *Cancel )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : FileDownload" );


	return;
}

#define DISPID_FRAMEBEFORENAVIGATE    200
#define DISPID_FRAMENAVIGATECOMPLETE  201
#define DISPID_FRAMENEWWINDOW         204

#define DISPID_NAVIGATECOMPLETE 101

#define DISPID_NAVIGATECOMPLETE2 252
void
NavigateComplete2( IDispatch *pDisp, VARIANT *URL )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : NavigateComplete2" );


	// [Mechanism]
	//
	//	V_BSTR( url )

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( URL ) );


	return;
}

#define DISPID_NAVIGATEERROR 271
void
NavigateError
(
	IDispatch    *pDisp,
	VARIANT      *URL,
	VARIANT      *TargetFrameName,
	VARIANT      *StatusCode,
	VARIANT_BOOL *Cancel
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : NavigateError" );


	// [Mechanism]
	//
	//	V_BSTR( url )
	//	V_BSTR( TargetFrameName )
	//	V_I4( StatusCode )

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( URL ) );
N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( TargetFrameName ) );


	return;
}

typedef enum NewProcessCauseConstants {

	ProtectedModeRedirect = 0x1

} NewProcessCauseConstants;

#define DISPID_NEWPROCESS 284
void
NewProcess
(      
	long         lCauseFlag,
	IDispatch    *pWB2,
	VARIANT_BOOL *Cancel
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IE8.0 : NewProcess" );


	return;
}

#define DISPID_NEWWINDOW 107

#define DISPID_NEWWINDOW2 251
void
NewWindow2( IDispatch **ppDisp, VARIANT_BOOL *Cancel )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : NewWindow2" );


	(*Cancel) = VARIANT_TRUE;


	return;
}

#define DISPID_NEWWINDOW3 273
void
NewWindow3
(      
	IDispatch    **ppDisp,
	VARIANT_BOOL  *Cancel,
	DWORD          dwFlags,
	BSTR           bstrUrlContext,
	BSTR           bstrUrl
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IE6.0 : XP SP2 : NewWindow3" );


	(*Cancel) = VARIANT_TRUE;


	return;
}

#define DISPID_ONADDRESSBAR 261
void
OnAddressBar( VARIANT_BOOL Visible )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnAddressBar" );


	// [!] : IWebBrowser2_put_AddressBar(); is called


	return;
}

#define DISPID_ONFULLSCREEN 258
void
OnFullScreen( VARIANT_BOOL FullScreen )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnFullScreen" );


	return;
}

#define DISPID_ONMENUBAR 256
void
OnMenuBar( VARIANT_BOOL MenuBar )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnMenuBar" );


	// [!] : IWebBrowser2_put_MenuBar(); is called


	return;
}

#define DISPID_QUIT   103
#define DISPID_ONQUIT 253
void
OnQuit( VOID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnQuit" );


	// [!] : don't use SendMessage()

	//n_win_message_post( b.hwnd_parent, WM_CLOSE, 0,0 );


	return;
}

#define DISPID_ONSTATUSBAR 257
void
OnStatusBar( VARIANT_BOOL StatusBar )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnStatusBar" );


	// [!] : IWebBrowser2_put_StatusBar(); is called


	return;
}

#define DISPID_ONTHEATERMODE 260
void
OnTheaterMode( VARIANT_BOOL TheaterMode )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnTheaterMode" );


	return;
}

#define DISPID_ONTOOLBAR 255
void
OnToolBar( VARIANT_BOOL ToolBar )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnToolBar" );


	// [!] : IWebBrowser2_put_ToolBar(); is called


	return;
}

#define DISPID_ONVISIBLE 254
void
OnVisible( VARIANT_BOOL Visible )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnVisible" );


	return;
}

#define DISPID_PRINTTEMPLATEINSTANTIATION 225
void
PrintTemplateInstantiation( IDispatch *pDisp )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : PrintTemplateInstantiation" );


	// [!] : Print Preview Window turns ON


	return;
}

#define DISPID_PRINTTEMPLATETEARDOWN 226
void
PrintTemplateTeardown( IDispatch *pDisp )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : PrintTemplateTeardown" );


	// [!] : Print Preview Window is closed


	return;
}

#define DISPID_PRIVACYIMPACTEDSTATECHANGE 272
void
PrivacyImpactedStateChange( VARIANT_BOOL PrivacyImpacted )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE6.0 : PrivacyImpactedStateChange" );


	// [!] : "Cookie is blocked" dialog is appeared


	return;
}

#define DISPID_PROGRESSCHANGE 108
void
ProgressChange( long Progress, long ProgressMax )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : ProgressChange" );


	return;
}

#define DISPID_PROPERTYCHANGE 112
void
PropertyChange( BSTR szProperty )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : PropertyChange" );

N_COM_DEBUG_LISTBOX_SET_W( szProperty );

	return;
}

#define DISPID_SETPHISHINGFILTERSTATUS 282
void
SetPhishingFilterStatus( long PhishingFilterStatus )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE7.0 : SetPhishingFilterStatus" );


	return;
}

#define DISPID_SETSECURELOCKICON 269
void
SetSecureLockIcon( long SecureLockIcon )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : SetSecureLockIcon" );


	return;
}

#define DISPID_STATUSTEXTCHANGE 102
void
StatusTextChange( BSTR Text )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : StatusTextChange" );

N_COM_DEBUG_LISTBOX_SET_W( Text );


	return;
}

#define DISPID_TITLECHANGE 113
void
TitleChange( BSTR Text )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : TitleChange" );

N_COM_DEBUG_LISTBOX_SET_W( Text );


	return;
}

//UpdatePageStatus : MSDN says "Not implemented."

#define DISPID_WINDOWCLOSING 263
void
WindowClosing( VARIANT_BOOL IsChildWindow, VARIANT_BOOL *Cancel )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowClosing" );


	//(*Cancel) = VARIANT_TRUE;


	return;
}

#define DISPID_WINDOWSETHEIGHT 267
void
WindowSetHeight( long Height )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetHeight" );


	return;
}

#define DISPID_WINDOWSETLEFT 264
void
WindowSetLeft( long Left )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetLeft" );


	return;
}

#define DISPID_WINDOWSETRESIZABLE 262
void
WindowSetResizable( VARIANT_BOOL Resizable )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetResizable" );


	return;
}

#define DISPID_WINDOWSETTOP 265
void
WindowSetTop( long Top )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetTop" );


	return;
}

#define DISPID_WINDOWSETWIDTH 266
void
WindowSetWidth( long Width )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetWidth" );


	return;
}

#define DISPID_WINDOWSTATECHANGED 283
void
WindowStateChanged( DWORD dwFlags, DWORD dwValidFlagsMask )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE6.0 : XP SP2 : WindowStateChanged" );


	return;
}

HRESULT __stdcall
n_DWebBrowserEvents2_IDispatch_Invoke
(
	void         *_this,
	DISPID        dispIdMember,
	REFIID        riid,
	LCID          lcid,
	WORD          wFlags,
	DISPPARAMS   *pDispParams,
	VARIANT      *pVarResult,
	EXCEPINFO    *pExcepInfo,
	unsigned int *puArgErr
)
{

	// DISPID_* : exdispid.h
	// VARIANT  : oaidl.h

	// IE6 calling sequence
	//
	// 01 : 112 : DISPID_PROPERTYCHANGE
	// 02 : 250 : DISPID_BEFORENAVIGATE2
	// 03 : 106 : DISPID_DOWNLOADBEGIN
	// 04 : 112 : DISPID_PROPERTYCHANGE
	// 05 : 102 : DISPID_STATUSTEXTCHANGE
	// 06 : 108 : DISPID_PROGRESSCHANGE
	// 07 : 102 : DISPID_STATUSTEXTCHANGE
	// 08 : 102 : DISPID_STATUSTEXTCHANGE
	// 09 : 270 : DISPID_FILEDOWNLOAD
	// 10 : 104 : DISPID_DOWNLOADCOMPLETE
	// 11 : 102 : DISPID_STATUSTEXTCHANGE
	// 12 : --- : hang-up when called without WndProc()

/*
	n_com_debug_IDispatch_Invoke
	(
		_this,
		dispIdMember,
		riid,
		lcid,
		wFlags,
		pDispParams,
		pVarResult,
		pExcepInfo,
		puArgErr
	);
*/

	switch( dispIdMember ) {


	case DISPID_BEFORENAVIGATE2 :

		BeforeNavigate2
		(
			pDispParams->rgvarg[6].pdispVal,
			pDispParams->rgvarg[5].pvarVal,
			pDispParams->rgvarg[4].pvarVal,
			pDispParams->rgvarg[3].pvarVal,
			pDispParams->rgvarg[2].pvarVal,
			pDispParams->rgvarg[1].pvarVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_CLIENTTOHOSTWINDOW :

		ClientToHostWindow
		(
			pDispParams->rgvarg[1].plVal,
			pDispParams->rgvarg[0].plVal
		);

	break;

	case DISPID_COMMANDSTATECHANGE :

		CommandStateChange
		(
			pDispParams->rgvarg[1].lVal,
			pDispParams->rgvarg[0].boolVal
		);

	break;

	case DISPID_DOCUMENTCOMPLETE :

		DocumentComplete
		(
			pDispParams->rgvarg[1].pdispVal,
			pDispParams->rgvarg[0].pvarVal
		);

	break;

	case DISPID_DOWNLOADBEGIN :

		DownloadBegin();

	break;

	case DISPID_DOWNLOADCOMPLETE :

		DownloadComplete();

	break;

	case DISPID_FILEDOWNLOAD :

		FileDownload
		(
			pDispParams->rgvarg[1].pboolVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NAVIGATECOMPLETE2 :

		NavigateComplete2
		(
			pDispParams->rgvarg[1].pdispVal,
			pDispParams->rgvarg[0].pvarVal
		);

	break;

	case DISPID_NAVIGATEERROR :

		NavigateError
		(
			pDispParams->rgvarg[4].pdispVal,
			pDispParams->rgvarg[3].pvarVal,
			pDispParams->rgvarg[2].pvarVal,
			pDispParams->rgvarg[1].pvarVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NEWPROCESS :

		NewProcess
		(      
			pDispParams->rgvarg[2].lVal,
			pDispParams->rgvarg[1].pdispVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NEWWINDOW2 :

		NewWindow2
		(
			pDispParams->rgvarg[1].ppdispVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NEWWINDOW3 :

		NewWindow3
		(
			pDispParams->rgvarg[4].ppdispVal,
			pDispParams->rgvarg[3].pboolVal,
			pDispParams->rgvarg[2].ulVal,
			pDispParams->rgvarg[1].bstrVal,
			pDispParams->rgvarg[0].bstrVal
		);

	break;

	case DISPID_ONADDRESSBAR :

		OnAddressBar( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONFULLSCREEN :

		OnFullScreen( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONMENUBAR :

		OnMenuBar( pDispParams->rgvarg[0].boolVal );
	break;

	case DISPID_ONQUIT :

		OnQuit();

	break;

	case DISPID_ONSTATUSBAR :

		OnStatusBar( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONTHEATERMODE :

		OnTheaterMode( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONTOOLBAR :

		OnToolBar( pDispParams->rgvarg[0].boolVal );
	break;

	case DISPID_ONVISIBLE :

		OnVisible( pDispParams->rgvarg[0].boolVal );
	break;

	case DISPID_PRINTTEMPLATEINSTANTIATION :

		PrintTemplateInstantiation( pDispParams->rgvarg[0].pdispVal );

	break;

	case DISPID_PRINTTEMPLATETEARDOWN :

		PrintTemplateTeardown( pDispParams->rgvarg[0].pdispVal );

	break;

	case DISPID_PRIVACYIMPACTEDSTATECHANGE :

		PrivacyImpactedStateChange( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_PROGRESSCHANGE :

		ProgressChange
		(
			pDispParams->rgvarg[1].lVal,
			pDispParams->rgvarg[0].lVal
		);

	break;

	case DISPID_PROPERTYCHANGE :

		PropertyChange( pDispParams->rgvarg[0].bstrVal );

	break;

	case DISPID_SETPHISHINGFILTERSTATUS :

		SetPhishingFilterStatus( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_SETSECURELOCKICON :

		SetSecureLockIcon( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_STATUSTEXTCHANGE :

		StatusTextChange( pDispParams->rgvarg[0].bstrVal );

	break;

	case DISPID_TITLECHANGE :

		TitleChange( pDispParams->rgvarg[0].bstrVal );

	break;

	case DISPID_WINDOWCLOSING :

		WindowClosing
		(
			pDispParams->rgvarg[1].boolVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_WINDOWSETHEIGHT :

		WindowSetHeight( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSETLEFT :

		WindowSetLeft( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSETRESIZABLE :

		WindowSetResizable( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_WINDOWSETTOP :

		WindowSetTop( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSETWIDTH :

		WindowSetWidth( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSTATECHANGED :

		WindowStateChanged
		(
			pDispParams->rgvarg[1].ulVal,
			pDispParams->rgvarg[0].ulVal
		);

	break;


	case DISPID_AMBIENT_DLCONTROL :
N_COM_DEBUG_LISTBOX_SET_A( "DISPID_AMBIENT_DLCONTROL" );

	break;


	default :
N_COM_DEBUG_LISTBOX_SET_A( "DISP_E_MEMBERNOTFOUND" );

		return DISP_E_MEMBERNOTFOUND;

	break;


	} // switch


	return S_OK;
}




const void *n_DWebBrowserEvents2_Vtbl[] = {

	n_DWebBrowserEvents2_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,
	n_com_IDispatch_GetTypeInfoCount,
	n_com_IDispatch_GetTypeInfo,
	n_com_IDispatch_GetIDsOfNames,
	n_DWebBrowserEvents2_IDispatch_Invoke

};


DWebBrowserEvents2 n_DWebBrowserEvents2_instance = { (void*) n_DWebBrowserEvents2_Vtbl };




#endif // _H_NONNON_WIN32_COM_DWEBBROWSEREVENTS2

