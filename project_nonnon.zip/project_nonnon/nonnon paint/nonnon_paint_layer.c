// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_PAINT_LAYER_INI_FILENAME n_posix_literal( "nonnon_paint.ini" )
#define N_PAINT_LAYER_INI_SECTION  n_posix_literal( "[Nonnon Paint Layer]" )
#define N_PAINT_LAYER_INI_INDEX    n_posix_literal( "index  " )
#define N_PAINT_LAYER_INI_NUMBER   n_posix_literal( "number " )
#define N_PAINT_LAYER_INI_NAME     n_posix_literal( "name   " )
#define N_PAINT_LAYER_INI_VISIBLE  n_posix_literal( "visible" )
#define N_PAINT_LAYER_INI_PERCENT  n_posix_literal( "percent" )
#define N_PAINT_LAYER_INI_BLUR     n_posix_literal( "blur   " )
#define N_PAINT_LAYER_TITLE        n_posix_literal( "Layer"   )




static n_win_scroller   n_paint_layer_scr_blend;
static n_win_scroller   n_paint_layer_scr_blur;
static n_win_check      n_paint_layer_chk_wholegrb;
//static n_win_check      n_paint_layer_chk_move_grb;
static n_win_simplemenu n_paint_layer_simplemenu;
static int              n_paint_layer_first_index = 0;




void
n_bmp_layer_free( n_paint_layer *p )
{

	int i = 0;
	while( 1 )
	{

		n_bmp_free( &p[ i ].bmp_data );
		n_bmp_free( &p[ i ].bmp_grab );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return;
}

#define n_bmp_layer_alias( f, t ) n_memory_copy( f, t, sizeof( n_paint_layer ) * n_paint_layer_count )

void
n_bmp_layer_copy( n_paint_layer *f, n_paint_layer *t )
{

	n_memory_copy( f, t, sizeof( n_paint_layer ) * n_paint_layer_count );

	int i = 0;
	while( 1 )
	{

		n_bmp_carboncopy( &f[ i ].bmp_data, &t[ i ].bmp_data );
		n_bmp_carboncopy( &f[ i ].bmp_grab, &t[ i ].bmp_grab );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return;
}

inline u32
n_paint_layer_blur_pixel( n_bmp *bmp, s32 x, s32 y, int blur )
{

	u32 ret;


	if ( blur == 0 )
	{
		n_bmp_ptr_get( bmp, x, y, &ret );
	} else
	if ( blur == 1 )
	{
		ret = n_bmp_antialias_pixel( bmp, x, y, 1.0 );
	} else {
		ret = n_bmp_blur_pixel( bmp, x, y, blur, 1.0 );
	}


	return ret;
}

// internal
void
n_paint_layer_grabber_pixel_get( n_bmp *grab, s32 tx, s32 ty, u32 picked, u32 *before, u32 *after, double blend, int i )
{

	// [!] : this module is based on n_paint_grabber_pixel_get()


	u32 color_b, color_a;


	// [x] : don't use _fast()

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		//n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_b );

		color_b = n_bmp_antialias_pixel( n_paint_bmp_data, tx,ty, blend );
		color_a = picked;

	} else {

		s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


		s32 gx = tx - x;
		s32 gy = ty - y;

		if ( n_bmp_ptr_is_accessible( grab, gx,gy ) )
		{
			//n_bmp_ptr_get_fast(             grab, gx,gy, &color_b );
			//color_b = n_bmp_antialias_pixel(             grab, gx,gy, blend );

			color_b = n_paint_layer_blur_pixel( &n_paint_layer_data[ i ].bmp_grab, gx, gy, n_paint_layer_data[ i ].blur );
		} else {
			//n_bmp_ptr_get     ( n_paint_bmp_data, tx,ty, &color_b );
			//color_b = n_bmp_antialias_pixel( n_paint_bmp_data, tx,ty, blend );

			color_b = n_paint_layer_blur_pixel( &n_paint_layer_data[ i ].bmp_data, tx, ty, n_paint_layer_data[ i ].blur );
		}


		// [!] : Eraser

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( picked ) )
		//if ( false )
		{
			n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_a );
		} else {
			color_a = picked;
		}

	}


	if ( before != NULL ) { (*before) = color_b; }
	if ( after  != NULL ) { (*after ) = color_a; }


	return;
}

inline u32
n_paint_layer_canvas_grabber_pixel( n_bmp *grab, s32 tx, s32 ty, u32 color, int i )
{

	// [!] : this module is based on n_paint_canvas_grabber_pixel()

 
	u32 color_grab; n_paint_layer_grabber_pixel_get( grab, tx, ty, 0, &color_grab, NULL, 0.0, i );


	if ( n_paint_tool_per_pixel_alpha_onoff )
	{
		int    a = n_bmp_a( color_grab );
		double b = n_bmp_blend_alpha2ratio( a );

		if ( a != N_BMP_ALPHA_CHANNEL_VISIBLE )
		{
			color_grab = n_bmp_blend_pixel( color_grab, color, b );
//color_grab = n_bmp_rgb( 0,200,255 );
		}

		if ( n_paint_grabber_is_rotated )
		{
			s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

			s32 gx = tx - x;
			s32 gy = ty - y;

			if ( n_bmp_ptr_is_accessible( n_paint_bmp_grab, gx,gy ) )
			{
				color_grab = n_bmp_composite_pixel( grab, &n_paint_layer_data[ i ].bmp_data, gx,gy, tx,ty, true, b );
			}
		}
	}


	if ( n_paint_tool_blend )
	{
		color_grab = n_bmp_blend_pixel( color_grab, color, n_paint_tool_blend_ratio );
	}


	return color_grab;
}

u32
n_bmp_layer_ptr_get( n_paint_layer *p, s32 tx, s32 ty, bool use_color_bg, u32 color_bg, bool is_ui )
{

	u32 ret = n_bmp_white_invisible;
//return n_bmp_rgb( 0,200,255 );

	if ( false == n_bmp_ptr_is_accessible( &p[ 0 ].bmp_data, tx, ty ) ) { return ret; }


	u32 color_prev = n_paint_layer_blur_pixel( &p[ 0 ].bmp_data, tx, ty, p[ 0 ].blur );


	if ( NULL == N_BMP_PTR( &p[ 1 ].bmp_data ) )
	{
		if ( grabber )
		{
			ret = n_paint_layer_canvas_grabber_pixel( n_paint_bmp_grab, tx, ty, color_prev, 0 );
		} else {
			ret = color_prev;
		}
//return n_bmp_rgb( 0,200,255 );
		return ret;
	} else {
		if ( ( use_color_bg )&&( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( color_prev ) ) )
		{
			ret = color_prev = color_bg;
//return n_bmp_rgb( 0,200,255 );
		} else {
			ret = color_prev;
			if ( false == p[ 0 ].visible ) { color_prev = color_bg; }
//return n_bmp_rgb( 255,0,200 );
		}
	}


	s32 x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


	int i = 0;
	while( 1 )
	{//break;

		if ( p[ i ].visible )
		{

			u32 color;

			if ( i == 0 )
			{
				color = color_prev;
			} else {
				color = n_paint_layer_blur_pixel( &p[ i ].bmp_data, tx, ty, p[ i ].blur );
			}


			if ( ( is_ui )&&( grabber ) )
			{
				color = n_paint_layer_canvas_grabber_pixel( &n_paint_layer_data[ i ].bmp_grab, tx, ty, color, i );
//color = n_bmp_rgb( 0,200,255 );
			}

			ret = n_bmp_composite_pixel_postprocess( color_prev, color, n_bmp_a( color ), true, true, true, 1.0 - p[ i ].blend, NULL );
//if ( n_win_is_input( VK_LBUTTON ) ) { ret = n_bmp_rgb( 0,200,255 ); }

			color_prev = ret;

		} else {

			ret = color_prev;

		}


		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return ret;
}

typedef struct {

	n_paint_layer *layer;
	n_bmp         *bmp_t;
	s32            x,y,sx,sy, tx,ty;
	u32            color_bg;
	bool           is_ui;
	s32            oy, cores;

} n_bmp_layercopy_thread_struct;

void
n_bmp_layercopy_thread_main( n_bmp_layercopy_thread_struct *p )
{

	s32 x = 0;
	s32 y = p->oy; if ( y >= p->sy ) { return; }
	while( 1 )
	{

		u32 color = n_bmp_layer_ptr_get( p->layer, p->x + x, p->y + y, true, p->color_bg, p->is_ui );
		n_bmp_ptr_set_fast( p->bmp_t, p->tx + x, p->ty + y, color );

		x++;
		if ( x >= p->sx )
		{

			x = 0;

			y += p->cores;
			if ( y >= p->sy ) { break; }
		}
	}


	return;
}

n_thread_return
n_bmp_layercopy_thread( n_thread_argument p )
{

	n_bmp_layercopy_thread_main( p );

	return 0;
}

#define n_bmp_layercopy( l,b, x,y,sx,sy, tx,ty, is_ui ) n_bmp_layercopy_main( l,b, x,y,sx,sy, tx,ty, n_bmp_white_invisible, is_ui )

// internal
void
n_bmp_layercopy_main( n_paint_layer *layer, n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, s32 tx, s32 ty, u32 color_bg, bool is_ui )
{
//return;

	if ( n_bmp_error_clipping( &layer[ 0 ].bmp_data,bmp, &x,&y,&sx,&sy, &tx,&ty ) ) { return; }


	// [x] : Win9x : can run but not working

	// [!] : very heavy : multi-thread is always needed

	if (
//(0)&&
		( n_thread_onoff() )
		//&&
		//( ( sx * sy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_bmp_layercopy() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_bmp_safemode_base = false;


		bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = true;


		s32 cores = n_thread_core_count;

		n_thread                      *h = n_memory_new( cores * sizeof( n_thread                      ) );
		n_bmp_layercopy_thread_struct *p = n_memory_new( cores * sizeof( n_bmp_layercopy_thread_struct ) );


		size_t i = 0;
		while( 1 )
		{

			n_bmp_layercopy_thread_struct tmp = { layer, bmp, x,y,sx,sy, tx,ty, color_bg, is_ui, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_bmp_layercopy_thread_struct ) );

			h[ i ] = n_thread_init( n_bmp_layercopy_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;


		n_bmp_safemode_base = true;

	} else {

		n_bmp_layercopy_thread_struct p = { layer, bmp, x,y,sx,sy, tx,ty, color_bg, is_ui, 0,1 };

		n_bmp_layercopy_thread_main( &p );

	}


	return;
}

void
n_bmp_layer_fill( n_paint_layer *p, s32 x, s32 y, u32 color )
{

	// [!] : fail-safe

	u32 color_to;

	int found = 0;
	int index = 0;
	while( 1 )
	{
		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_bmp_ptr_get( &p[ index ].bmp_data, x,y, &color_to );
		} else {
			n_bmp_ptr_get( &p[ index ].bmp_grab, x,y, &color_to );
		}
		if ( color == color_to ) { found++; }

		index++;
		if ( index >= n_paint_layer_count ) { break; }
	}
//n_posix_debug_literal( " %d ", found ); return 0;
	if ( found != 0 ) { return; }


	s32 bmpsx = N_BMP_SX( &p[ 0 ].bmp_data );
	s32 bmpsy = N_BMP_SY( &p[ 0 ].bmp_data );

	u8 *map = n_memory_new_closed( bmpsx * bmpsy * sizeof( u8 ) );


	u32 t    = 0;
	int move = 0;
	int stop = 0;
	u32 i    = 0;
	while( 1 )
	{

		int found = 0;
		int index = 0;
		while( 1 )
		{

			if ( p[ index ].visible )
			{
				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					bool ret = n_bmp_ptr_get( &p[ index ].bmp_data, x,y, &t );
					if ( ( ret == false )&&( t == color_to ) ) { found++; }
				} else {
					bool ret = n_bmp_ptr_get( &p[ index ].bmp_grab, x,y, &t );
					if ( ( ret == false )&&( t == color_to ) ) { found++; }
				}
			} else {
				found++;
			}

			index++;
			if ( index >= n_paint_layer_count ) { break; }
		}

		if ( found == n_paint_layer_count )
		{

			stop = 0;

			int index = 0;
			while( 1 )
			{

				if ( p[ index ].visible )
				{
					if ( N_PAINT_GRABBER_IS_NEUTRAL() )
					{
						n_bmp_ptr_set( &p[ index ].bmp_data, x,y, color );
					} else {
						n_bmp_ptr_set( &p[ index ].bmp_grab, x,y, color );
					}
				}

				index++;
				if ( index >= n_paint_layer_count ) { break; }
			}

			map[ i ] = move;

			i++;

		} else {

			if ( move == 0 ) { y++; } else
			if ( move == 1 ) { x--; } else
			if ( move == 2 ) { y--; } else
			if ( move == 3 ) { x++; }

			stop++;
			if ( stop >= 4 )
			{

				stop = 0;

				if ( i <= 1 ) { break; }


				i--;

				move = map[ i ];
				if ( move == 0 ) { y++; } else
				if ( move == 1 ) { x--; } else
				if ( move == 2 ) { y--; } else
				if ( move == 3 ) { x++; }

			}

			move++;
			if ( move >= 4 ) { move = 0; }

		}

		if ( move == 0 ) { y--; } else
		if ( move == 1 ) { x++; } else
		if ( move == 2 ) { y++; } else
		if ( move == 3 ) { x--; }

	}


	n_memory_free_closed( map );


	return;
}




void
n_paint_layer_bmp_flush( u32 color )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{

		int i = 0;
		while( 1 )
		{

			if ( n_paint_layer_data[ i ].visible )
			{
				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_data, color );
				} else {
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_grab, color );
				}
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( n_paint_layer_onoff )
	{

		int y = n_paint_layer_txtbox.select_cch_y;

		if ( n_paint_layer_data[ y ].visible )
		{
			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_flush( n_paint_bmp_data, color );
			} else {
				n_bmp_flush( n_paint_bmp_grab, color );
			}
		}

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_bmp_flush( n_paint_bmp_data, color );
		} else {
			n_bmp_flush( n_paint_bmp_grab, color );
		}

	}

	return;
}

void
n_paint_layer_bmp_flush_replacer( u32 f, u32 t )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{

		int i = 0;
		while( 1 )
		{

			if ( n_paint_layer_data[ i ].visible )
			{
				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					n_bmp_flush_replacer( &n_paint_layer_data[ i ].bmp_data, f, t );
				} else {
					n_bmp_flush_replacer( &n_paint_layer_data[ i ].bmp_grab, f, t );
				}
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( n_paint_layer_onoff )
	{

		int y = n_paint_layer_txtbox.select_cch_y;

		if ( n_paint_layer_data[ y ].visible )
		{
			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_flush_replacer( n_paint_bmp_data, f, t );
			} else {
				n_bmp_flush_replacer( n_paint_bmp_grab, f, t );
			}
		}

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_bmp_flush_replacer( n_paint_bmp_data, f, t );
		} else {
			n_bmp_flush_replacer( n_paint_bmp_grab, f, t );
		}

	}


	return;
}

bool
n_paint_layer_bmp_fill( n_bmp *bmp )
{

	u32 color = n_bmp_argb( cp.a, cp.r, cp.g, cp.b );

	s32 tx,ty; n_paint_canvaspos( &tx,&ty );

	if ( n_paint_grabber_wholegrb_onoff )
	{

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{

			n_bmp_layer_fill( n_paint_layer_data, tx,ty, color );

		} else {

			s32 x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

			n_bmp_layer_fill( n_paint_layer_data, tx - x,ty - y, color );

		}

		n_paint_refresh_client();

		return true;

	} else
	if ( n_paint_layer_onoff )
	{

		int index = n_paint_layer_txtbox.select_cch_y;

		if ( n_paint_layer_data[ index ].visible )
		{
			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_fill( n_paint_bmp_data, tx,ty, color );
				n_paint_refresh_client();

				return true;
			} else {
				s32 x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );
				n_bmp_fill( &n_paint_layer_data[ n_paint_grabber_selected_index ].bmp_grab, tx - x, ty - y, color );
				n_paint_refresh_client();

				return true;
			}
		}

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{

			n_bmp_fill( n_paint_bmp_data, tx,ty, color );
			n_paint_refresh_client();

			return true;
		}

		s32 x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

		n_bmp_carboncopy( n_paint_bmp_grab, bmp );
		n_bmp_fill( bmp, tx - x, ty - y, color );

	}


	return false;
}

typedef struct {

	n_bmp *bmp_f;
	n_bmp *bmp_t;
	u64    count;
	s32    oy, cores;

	bool   ret;

} n_paint_layer_bmp_is_same_thread_struct;

void
n_paint_layer_bmp_is_same_thread_main( n_paint_layer_bmp_is_same_thread_struct *p )
{

	p->ret = true;

	u64 i = p->oy; if ( i >= p->count ) { return; }
	while( 1 )
	{

		if ( N_BMP_PTR( p->bmp_f )[ i ] != N_BMP_PTR( p->bmp_t )[ i ] )
		{
			p->ret = false;
			break;
		}


		i += p->cores;
		if ( i >= p->count ) { break; }
	}


	return;
}

n_thread_return
n_paint_layer_bmp_is_same_thread( n_thread_argument p )
{

	n_paint_layer_bmp_is_same_thread_main( p );

	return 0;
}

bool
n_paint_layer_bmp_is_same( n_bmp *bmp_f, n_bmp *bmp_t )
{

	bool ret = false;


	if ( n_bmp_error( bmp_f ) ) { return ret; }
	if ( n_bmp_error( bmp_t ) ) { return ret; }


	if ( N_BMP_SX( bmp_f ) != N_BMP_SX( bmp_t ) ) { return ret; }
	if ( N_BMP_SY( bmp_f ) != N_BMP_SY( bmp_t ) ) { return ret; }


	// [x] : Win9x : can run but not working

	u64 count = N_BMP_SX( bmp_f ) * N_BMP_SY( bmp_f );

//u32 tick = n_posix_tickcount();

	if (
//(0)&&
		( n_thread_onoff() )
		&&
		( count >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_layer_bmp_is_same() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = true;


		s32 cores = n_thread_core_count;

		n_thread                                *h = n_memory_new( cores * sizeof( n_thread                                ) );
		n_paint_layer_bmp_is_same_thread_struct *p = n_memory_new( cores * sizeof( n_paint_layer_bmp_is_same_thread_struct ) );


		size_t i = 0;
		while( 1 )
		{

			n_paint_layer_bmp_is_same_thread_struct tmp = { bmp_f,bmp_t, count, i,cores, false };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_layer_bmp_is_same_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_layer_bmp_is_same_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			ret |= p[ i ].ret;

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_paint_layer_bmp_is_same_thread_struct tmp = { bmp_f,bmp_t, count, 0,1, false };
		n_paint_layer_bmp_is_same_thread_main( &tmp );

		ret = tmp.ret;

	}

//n_posix_debug_literal( " %d ", (int) n_posix_tickcount() - tick );


	return ret;
}

typedef struct {

	n_bmp *bmp;
	u64    count;
	s32    oy, cores;

	bool   ret;

} n_paint_layer_bmp_is_empty_thread_struct;

void
n_paint_layer_bmp_is_empty_thread_main( n_paint_layer_bmp_is_empty_thread_struct *p )
{

	p->ret = true;

	u64 i = p->oy; if ( i >= p->count ) { return; }
	while( 1 )
	{

		if ( N_BMP_PTR( p->bmp )[ i ] != n_bmp_white_invisible )
		{
			p->ret = false;
			break;
		}


		i += p->cores;
		if ( i >= p->count ) { break; }
	}


	return;
}

n_thread_return
n_paint_layer_bmp_is_empty_thread( n_thread_argument p )
{

	n_paint_layer_bmp_is_empty_thread_main( p );

	return 0;
}

bool
n_paint_layer_bmp_is_empty( n_bmp *bmp )
{

	bool ret = true;


	if ( n_bmp_error( bmp ) ) { return ret; }


	// [x] : Win9x : can run but not working

	u64 count = N_BMP_SX( bmp ) * N_BMP_SY( bmp );

//u32 tick = n_posix_tickcount();

	if (
//(0)&&
		( n_thread_onoff() )
		&&
		( count >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_layer_bmp_is_empty() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = true;


		s32 cores = n_thread_core_count;

		n_thread                                 *h = n_memory_new( cores * sizeof( n_thread                                 ) );
		n_paint_layer_bmp_is_empty_thread_struct *p = n_memory_new( cores * sizeof( n_paint_layer_bmp_is_empty_thread_struct ) );


		size_t i = 0;
		while( 1 )
		{

			n_paint_layer_bmp_is_empty_thread_struct tmp = { bmp, count, i,cores, false };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_layer_bmp_is_empty_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_layer_bmp_is_empty_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			ret |= p[ i ].ret;

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_paint_layer_bmp_is_empty_thread_struct tmp = { bmp, count, 0,1, false };
		n_paint_layer_bmp_is_empty_thread_main( &tmp );

		ret = tmp.ret;

	}

//n_posix_debug_literal( " %d ", (int) n_posix_tickcount() - tick );


	return ret;
}




// internal
LRESULT CALLBACK
n_paint_layer_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( wparam == VK_RETURN )
	{
		ShowWindow( hwnd, SW_HIDE );
		SetFocus( n_paint_layer_txtbox.hwnd );

		return true;
	}


	return false;
}

void
n_paint_layer_on_keydown_init( void )
{

	HWND hgui = n_paint_layer_rename.hwnd;

#ifdef _WIN64

	SetWindowSubclass( hgui, n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_paint_layer_on_keydown );

#else  // #ifdef _WIN64

	n_win_property_init_literal
	(
		hgui,
		"n_win_subclass_txtbox_on_keydown()",
		(int) n_win_gui_subclass_set( hgui, n_win_subclass_txtbox_on_keydown )
	);

	n_win_property_init_literal( hgui, "WM_KEYDOWN", (int) n_paint_layer_on_keydown );

#endif // #ifdef _WIN64


	return;
}

void
n_paint_layer_on_keydown_exit( void )
{

	HWND hgui = n_paint_layer_rename.hwnd;

#ifdef _WIN64

	RemoveWindowSubclass( hgui, n_win_subclass_txtbox_on_keydown, 0 );

#else  // #ifdef _WIN64

	n_win_property_exit_literal
	(
		hgui,
		"n_win_subclass_txtbox_on_keydown()"
	);

	n_win_property_exit_literal( hgui, "WM_KEYDOWN" );

#endif // #ifdef _WIN64


	return;
}




#define n_paint_layer_selection_move_up(   y ) n_paint_layer_selection_move( y,  true )
#define n_paint_layer_selection_move_down( y ) n_paint_layer_selection_move( y, false )

// internal
void
n_paint_layer_selection_move( int y, bool is_up )
{

	if ( n_paint_layer_rename_onoff ) { return; }


	if ( is_up )
	{
		if ( y <= 0 ) { return; }

		n_paint_layer_txtbox.select_cch_y--;
	} else {
		if ( y >= ( n_paint_layer_count - 1 ) ) { return; }

		n_paint_layer_txtbox.select_cch_y++;
	}


	n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;


	n_paint_bmp_data = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_grab;


	int percent = n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].percent;
	n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", percent );
	n_win_refresh( n_paint_layer_scr_blend.value, true );

	int blur = n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].blur;
	n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", blur );
	n_win_refresh( n_paint_layer_scr_blur.value, true );

	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blend, 1, 10, 100, percent, false );
	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blur , 1,  5,  25, blur   , false );

	if ( n_paint_layer_txtbox.select_cch_y == 0 )
	{
		nwscr_enable( &n_paint_layer_scr_blend, false );
	} else {
		nwscr_enable( &n_paint_layer_scr_blend,  true );
	}


	n_win_txtbox_autofocus( &n_paint_layer_txtbox );
	n_win_txtbox_refresh( &n_paint_layer_txtbox );

	n_bmp_free( &n_paint_bmp_name );
	n_paint_refresh_client();


	return;
}

#define n_paint_layer_swap_up(   y ) n_paint_layer_swap( y,  true )
#define n_paint_layer_swap_down( y ) n_paint_layer_swap( y, false )

// internal
void
n_paint_layer_swap( int y, bool is_up )
{

	if ( n_paint_layer_rename_onoff ) { return; }


	if ( is_up )
	{
		if ( y <= 0 ) { n_paint_layer_rename_target = 0; return; }

		n_paint_layer data_tmp      = n_paint_layer_data[ y - 1 ];
		n_paint_layer_data[ y - 1 ] = n_paint_layer_data[ y     ];
		n_paint_layer_data[ y     ] = data_tmp;

		n_posix_char *txtbox_tmp_line          = n_paint_layer_txtbox.txt.line[ y - 1 ];
		n_paint_layer_txtbox.txt.line[ y - 1 ] = n_paint_layer_txtbox.txt.line[ y     ];
		n_paint_layer_txtbox.txt.line[ y     ] = txtbox_tmp_line;

		n_paint_layer_txtbox.select_cch_y--;
	} else {
		if ( y >= ( n_paint_layer_count - 1 ) ) { n_paint_layer_rename_target = ( n_paint_layer_count - 1 ); return; }

		n_paint_layer data_tmp      = n_paint_layer_data[ y + 1 ];
		n_paint_layer_data[ y + 1 ] = n_paint_layer_data[ y     ];
		n_paint_layer_data[ y     ] = data_tmp;

		n_posix_char *txtbox_tmp_line          = n_paint_layer_txtbox.txt.line[ y + 1 ];
		n_paint_layer_txtbox.txt.line[ y + 1 ] = n_paint_layer_txtbox.txt.line[ y     ];
		n_paint_layer_txtbox.txt.line[ y     ] = txtbox_tmp_line;

		n_paint_layer_txtbox.select_cch_y++;
	}


	n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;


	n_paint_bmp_data = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_grab;


	n_win_txtbox_autofocus( &n_paint_layer_txtbox );
	n_win_txtbox_refresh( &n_paint_layer_txtbox );


	n_bmp_free( &n_paint_bmp_name );
	n_paint_refresh_client();


	return;
}

void
n_paint_layer_config_default( void )
{

	int i = 0;
	while( 1 )
	{
		n_paint_layer_data[ i ].visible =  true;
		n_paint_layer_data[ i ].percent =   100;
		n_paint_layer_data[ i ].blend   =   1.0;
		n_paint_layer_data[ i ].blur    =     0;

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return;
}

void
n_paint_layer_init( void )
{

	n_paint_layer_onoff = false;

	{
		int i = 0;
		while( 1 )
		{
			n_bmp_zero( &n_paint_layer_data[ i ].bmp_data );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}
	}

	n_paint_layer_config_default();

	n_bmp_zero( &n_paint_layer_as_one );

	n_ini_zero( &n_paint_layer_ini );


	n_win_simplemenu_zero( &n_paint_layer_simplemenu );

	n_win_txtbox_zero( &n_paint_layer_txtbox );
	n_win_txtbox_zero( &n_paint_layer_rename );

	n_win_scroller_zero( &n_paint_layer_scr_blend );
	n_win_scroller_zero( &n_paint_layer_scr_blur  );


	return;
}

void
n_paint_layer_reset( void )
{

	n_paint_layer_onoff = false;

	{
		int i = 1;
		while( 1 )
		{
			n_bmp_free_fast( &n_paint_layer_data[ i ].bmp_data );

			n_paint_layer_zero( &n_paint_layer_data[ i ] );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		n_paint_bmp_data = &n_paint_layer_data[ 0 ].bmp_data;
		n_paint_bmp_grab = &n_paint_layer_data[ 0 ].bmp_grab;
	}

	n_bmp_free( &n_paint_layer_as_one );

	n_ini_free( &n_paint_layer_ini );


	return;
}

void
n_paint_layer_exit( void )
{

	n_paint_layer_onoff = false;

	{
		int i = 0;
		while( 1 )
		{
			n_bmp_free( &n_paint_layer_data[ i ].bmp_data );
			n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

			n_bmp_free( &n_paint_layer_copy[ i ].bmp_data );
			n_bmp_free( &n_paint_layer_copy[ i ].bmp_grab );

			n_paint_layer_zero( &n_paint_layer_data[ i ] );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}
	}

	n_bmp_free( &n_paint_layer_as_one );

	n_ini_free( &n_paint_layer_ini );


	n_win_simplemenu_exit( &n_paint_layer_simplemenu );

	n_paint_layer_on_keydown_exit();

	n_win_txtbox_exit( &n_paint_layer_txtbox );
	n_win_txtbox_exit( &n_paint_layer_rename );

	n_win_scroller_exit( &n_paint_layer_scr_blend );
	n_win_scroller_exit( &n_paint_layer_scr_blur  );

	n_win_check_exit( &n_paint_layer_chk_wholegrb );
	//n_win_check_exit( &n_paint_layer_chk_move_grb );

	//n_win_statusbar_od_exit( &n_paint_layer_statusbar );


	return;
}

#define n_paint_layer_ini_read(  i ) n_paint_layer_ini_main( i,  true )
#define n_paint_layer_ini_write( i ) n_paint_layer_ini_main( i, false )

// internal
void
n_paint_layer_ini_main( n_ini *ini, bool is_read )
{

	if ( is_read )
	{
		n_posix_char str[ 100 ];
		n_ini_value_str( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX, N_STRING_EMPTY, str, 100 );

		n_paint_layer_first_index = n_posix_minmax( 0, n_paint_layer_count - 1, n_posix_atoi( str ) );
//n_posix_debug_literal( " %s : %d ", str, n_paint_layer_first_index );
	}


	int i = n_paint_layer_count - 1;
	while( 1 )
	{
		n_posix_char section[ 100 ];
		n_posix_sprintf_literal( section, "[%d]", i );

		n_ini_section_add( ini, section );

		if ( is_read )
		{
			{
				n_posix_char str[ 100 ];
				n_ini_value_str( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX, N_STRING_EMPTY, str, 100 );

				n_paint_layer_first_index = n_posix_minmax( 0, n_paint_layer_count - 1, n_posix_atoi( str ) );
//n_posix_debug_literal( " %s : %d ", str, n_paint_layer_first_index );
			}

			n_posix_char str[ N_PAINT_LAYER_CCH ];
			n_ini_value_str( ini, section, N_PAINT_LAYER_INI_NAME, N_STRING_EMPTY, str, N_PAINT_LAYER_CCH );

			bool visible = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_VISIBLE, true );
			int  percent = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_PERCENT,  100 );
			int     blur = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_BLUR   ,    0 );

			n_string_copy( str, n_paint_layer_data[ i ].name );

			n_paint_layer_data[ i ].visible = visible;
			n_paint_layer_data[ i ].percent = percent;
			n_paint_layer_data[ i ].blur    = blur;
			n_paint_layer_data[ i ].blend   = (double) percent * 0.01;
		} else {
			n_posix_char str[ N_PAINT_LAYER_CCH ];
			n_string_copy( n_paint_layer_data[ i ].name, str );
//n_posix_debug_literal( " ini_write() : %s", n_paint_layer_data[ i ].name );

			bool visible = n_paint_layer_data[ i ].visible;
			int  percent = n_paint_layer_data[ i ].percent;
			int     blur = n_paint_layer_data[ i ].blur;

			n_ini_key_add_str( ini, section, N_PAINT_LAYER_INI_NAME, str );

			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_VISIBLE, visible );
			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_PERCENT, percent );
			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_BLUR   , blur    );
		}

		i--;
		if ( i < 0 ) { break; }
	}


	if ( is_read )
	{
		n_ini_new( ini );
	} else {
		n_ini_section_add( ini, N_PAINT_LAYER_INI_SECTION );
		n_ini_key_add_int( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX , n_paint_layer_txtbox.select_cch_y );
		n_ini_key_add_int( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_NUMBER, n_paint_layer_count               );
	}


	return;
}

void
n_paint_layer_ui_init( const n_posix_char *name, n_ini *ini )
{

	if ( ini != &n_paint_layer_ini )
	{
		n_paint_layer_ini_read( ini );
//n_posix_debug_literal( " %d ", n_paint_layer_data[ n_paint_layer_count - 1 ].percent );

		n_ini_free( &n_paint_layer_ini );
		n_memory_copy( ini, &n_paint_layer_ini, sizeof( n_ini ) );
	}

/*
	i = 0;
	while( 1 )
	{

n_posix_debug_literal( " %d ", n_paint_layer_data[ i ].percent );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}
*/

	int cch = n_posix_strlen( name ) + n_posix_strlen( N_PAINT_EXT_LYR );

	n_string_path_free( n_paint_bmpname );
	n_paint_bmpname = n_string_alloccopy( cch, name );
	n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_bmpname );

	n_paint_format = N_PAINT_FORMAT_LYR;


	n_win_txtbox_reset( &n_paint_layer_txtbox );

	int i = 0;
	while( 1 )
	{

		n_posix_char str[ 100 ];
		if ( n_paint_layer_data[ i ].visible )
		{
			n_posix_sprintf_literal( str, "[B]%s", n_paint_layer_data[ i ].name );
		} else {
			n_posix_sprintf_literal( str, "[ ]%s", n_paint_layer_data[ i ].name );
		}

		n_win_txtbox_line_set( &n_paint_layer_txtbox, i, str );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}

//n_posix_debug_literal( " %d ", n_paint_layer_first_index );
	n_win_txtbox_line_select( &n_paint_layer_txtbox, n_paint_layer_first_index );

	int y = n_paint_layer_txtbox.select_cch_y;

	n_paint_layer_rename_target = y;


	int percent = n_paint_layer_data[ y ].percent;
	n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", percent );
	n_win_refresh( n_paint_layer_scr_blend.value, true );

	int blur = n_paint_layer_data[ y ].blur;
	n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", blur );
	n_win_refresh( n_paint_layer_scr_blur.value, true );

	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blend, 1, 10, 100, percent, false );
	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blur , 1,  5,  25, blur   , false );

	if ( y == 0 )
	{
		nwscr_enable( &n_paint_layer_scr_blend, false );
	} else {
		nwscr_enable( &n_paint_layer_scr_blend,  true );
	}


	n_win_txtbox_line_select( &n_paint_layer_txtbox, y );
	n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;

	n_win_txtbox_autofocus( &n_paint_layer_txtbox );
	n_win_txtbox_refresh( &n_paint_layer_txtbox );


	//n_win_statusbar_od_automove( &n_paint_layer_statusbar );


	n_paint_layer_onoff = true;


	ShowWindowAsync( hwnd_layr, SW_NORMAL );


	return;
}

bool
n_paint_layer_load_sniffer( const n_posix_char *cmdline )
{

	n_posix_char *name_ini = n_string_path_make_new( cmdline, N_PAINT_LAYER_INI_FILENAME );
//n_posix_debug_literal( "%s", name_ini );

	bool ret = ( false == n_posix_stat_is_exist( name_ini ) );

	n_string_path_free( name_ini );


	return ret;
}

bool
n_paint_layer_load( const n_posix_char *cmdline )
{
//return true;

	n_bmp_free( &n_paint_bmp_name );
//return true;


	n_posix_char *name;
	n_posix_char *name_ini;

	if ( n_posix_stat_is_dir( cmdline ) )
	{
		name     = n_string_path_carboncopy( cmdline );
		name_ini = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
	} else {
		name     = n_string_path_upperfolder_new( cmdline );
		name_ini = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
		if ( false == n_string_is_same( cmdline, name_ini ) )
		{
			n_string_path_free( name     );
			n_string_path_free( name_ini );

//n_posix_debug_literal( " %d %d %d ", n_paint_layer_count, grabber, tooltype );

			return true;
		}
	}
//return true;
//n_posix_debug_literal( "%s", name_ini );


	n_ini ini; n_ini_zero( &ini );
	bool ret = n_ini_load( &ini, name_ini );
//n_ini_free( &ini ); ret = true;


	if ( ret == false )
	{
		ret = n_ini_section_chk( &ini, N_PAINT_LAYER_INI_SECTION );
//n_posix_debug_literal( " n_ini_section_chk_literal() : %d ", ret );
		if ( ret ) { ret = false; } else { ret = true; }
	}
//n_ini_free( &ini ); ret = true;


	if ( ret == false )
	{

		n_bmp_layer_free( n_paint_layer_data );
		n_bmp_layer_free( n_paint_layer_copy );

		n_memory_free( n_paint_layer_data );
		n_memory_free( n_paint_layer_copy );


		n_paint_layer_count = n_ini_value_int( &ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_NUMBER, N_PAINT_LAYER_MAX );
		if ( n_paint_layer_count < N_PAINT_LAYER_MAX ) { n_paint_layer_count = N_PAINT_LAYER_MAX; }

		n_paint_layer_data = n_memory_new( sizeof( n_paint_layer ) * n_paint_layer_count );
		n_memory_zero( n_paint_layer_data, sizeof( n_paint_layer ) * n_paint_layer_count );

		n_paint_layer_copy = n_memory_new( sizeof( n_paint_layer ) * n_paint_layer_count );
		n_memory_zero( n_paint_layer_copy, sizeof( n_paint_layer ) * n_paint_layer_count );


		n_bmp *layer = n_memory_new_closed( sizeof( n_bmp ) * n_paint_layer_count );

		int i = 0;
		while( 1 )
		{
			n_bmp_zero( &layer[ i ] );

			n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%d.png", i );
			n_posix_char *name_img = n_string_path_make_new( name, str );

			bool ret2 = n_png_png2bmp( name_img, &layer[ i ] );
			if ( i == 0 )
			{

				if ( ret2 ) { ret = true; break; }

			} else {

				if ( ret2 )
				{
					s32 sx = N_BMP_SX( &layer[ 0 ] );
					s32 sy = N_BMP_SY( &layer[ 0 ] );
					n_bmp_new_fast( &layer[ i ], sx,sy );
					n_bmp_flush( &layer[ i ], n_bmp_white_invisible );
				} else
				if (
					( N_BMP_SX( &layer[ 0 ] ) != N_BMP_SX( &layer[ i ] ) )
					||
					( N_BMP_SY( &layer[ 0 ] ) != N_BMP_SY( &layer[ i ] ) )
				)
				{
					s32 sx = N_BMP_SX( &layer[ 0 ] );
					s32 sy = N_BMP_SY( &layer[ 0 ] );
					n_bmp_resizer( &layer[ i ], sx,sy, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );
				}

			}

//n_posix_debug_literal( " %s : %d ", name_img, ret );

			n_string_path_free( name_img );


			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		{

			int i = 0;
			while( 1 )
			{
				n_bmp_free_fast( &n_paint_layer_data[ i ].bmp_data );
				n_bmp_alias( &layer[ i ], &n_paint_layer_data[ i ].bmp_data );

				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}

		}

		n_memory_free_closed( layer );

	}


	if ( ret == false )
	{
		n_bmp_layer_free( n_paint_layer_copy );
		n_bmp_layer_copy( n_paint_layer_data, n_paint_layer_copy );

		n_paint_layer_ui_init( name, &ini );

		extern void n_paint_layer_resize( HWND hwnd, bool shade_onoff, bool is_init );
		n_paint_layer_resize( hwnd_layr, n_paint_layer_shade_onoff, true );
	} else {
		n_ini_free( &ini );
	}


	n_string_path_free( name     );
	n_string_path_free( name_ini );


	return ret;
}

void
n_paint_layer_save( void )
{

	bool is_init = false;

	if ( n_paint_layer_onoff == false )
	{

		is_init = true;

		n_paint_layer_onoff = true;

		s32 bmpsx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
		s32 bmpsy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

		int i = 1;
		while( 1 )
		{
			n_bmp_new( &n_paint_layer_data[ i ].bmp_data, bmpsx, bmpsy );
			n_bmp_flush( &n_paint_layer_data[ i ].bmp_data, n_bmp_white_invisible );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		n_paint_layer_config_default();

		i = 0;
		while( 1 )
		{

			n_string_truncate( n_paint_layer_data[ i ].name );

			if ( i == 0 )
			{
				n_posix_strcat( n_paint_layer_data[ i ].name, n_posix_literal( "Background" ) );
			} else
			if ( i == ( n_paint_layer_count - 1 ) )
			{
				n_posix_strcat( n_paint_layer_data[ i ].name, n_posix_literal( "Top" ) );
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}


		n_ini_new( &n_paint_layer_ini );

		n_paint_layer_ini_write( &n_paint_layer_ini );

//n_posix_debug_literal( " %d ", n_paint_layer_data[ 0 ].percent );

		n_bmp_layer_free( n_paint_layer_copy );
		n_bmp_layer_copy( n_paint_layer_data, n_paint_layer_copy );

	}


	n_posix_char *name = n_string_path_carboncopy( n_paint_bmpname );
	if ( n_paint_format_is_lyr( name ) ) { n_string_path_ext_del( name ); }


	n_posix_mkdir( name );


	//if ( 0 )
	{

		int i = 0;
		while( 1 )
		{

			n_bmp *bmp_f = &n_paint_layer_data[ i ].bmp_data;
			n_bmp *bmp_t = &n_paint_layer_copy[ i ].bmp_data;

			if (
				( ( is_init )&&( i == 0 ) )
				||
				( false == n_paint_layer_bmp_is_same( bmp_f, bmp_t ) )
				||
				( false == n_paint_layer_bmp_is_empty( bmp_f ) )
			)
			{
				n_png png = n_png_template;

				if ( false == n_bmp_error( &n_paint_layer_data[ i ].bmp_data ) )
				{
					n_png_compress( &png, &n_paint_layer_data[ i ].bmp_data );
				} else {
					s32 bmpsx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
					s32 bmpsy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

					n_bmp_new( &n_paint_layer_data[ i ].bmp_data, bmpsx, bmpsy );

					n_png_compress( &png, &n_paint_layer_data[ i ].bmp_data );
				}

				n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%d.png", i );
				n_posix_char *png_name = n_string_path_make_new( name, str );

				n_png_save( &png, png_name );

				n_string_path_free( png_name );

				n_png_free( &png );
			}


			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		if ( is_init == false )
		{
			n_bmp_layer_free( n_paint_layer_copy );
			n_bmp_layer_copy( n_paint_layer_data, n_paint_layer_copy );
		}

	}


	n_posix_char *ini_name = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
//n_posix_debug_literal( " %s ", ini_name );

	n_paint_layer_ini_write( &n_paint_layer_ini );

/*
	{

		int i = 0;
		while( 1 )
		{
n_posix_debug_literal( " %s ", n_paint_layer_data[ i ].name );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}
	}

	{

		int i = 0;
		while( 1 )
		{
			if ( i >= n_paint_layer_ini.sy ) { break; }

n_posix_debug_literal( " %s ", n_paint_layer_ini.line[ i ] );

			i++;
		}
	}
*/
	n_ini_save( &n_paint_layer_ini, ini_name );

	n_string_path_free( ini_name );


	if ( is_init )
	{
		n_paint_layer_ui_init( name, &n_paint_layer_ini );
	}


	n_string_path_free( name );


	return;
}

void
n_paint_layer_grabber_location( int y )
{
/*
	if ( y >= 0 )
	{
n_win_hwndprintf_literal( hwnd_layr, "%s : %s", N_PAINT_LAYER_TITLE, n_paint_layer_data[ y ].name );
	} else {
n_win_hwndprintf_literal( hwnd_layr, "%s", N_PAINT_LAYER_TITLE );
	}

	return;
*/

	int i = 0;
	while( 1 )
	{

		bool refresh = false;

		n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

		if ( nam[ 1 ] == n_posix_literal( 'u' ) )
		{
			refresh  = true;
			nam[ 1 ] = n_posix_literal( ' ' );
		} else
		if ( nam[ 1 ] == n_posix_literal( 'U' ) )
		{
			refresh  = true;
			nam[ 1 ] = n_posix_literal( 'B' );
		}

		if ( refresh ) { n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam ); }

		n_string_free( nam );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


//n_win_hwndprintf_literal( hwnd_layr, "%d", y );


	n_paint_layer_multiselect = false;


	i = 0;
	while( 1 )
	{//break;

		if (
			( y != -1 )
			&&
			( n_paint_grabber_wholegrb_onoff )
			&&
			( n_paint_layer_data[ i ].visible == false )
		)
		{
			n_paint_layer_multiselect = true;
		} else
		if (
			( y != -1 )
			&&
			( n_paint_grabber_wholegrb_onoff )
			&&
			( n_paint_layer_data[ i ].visible )
		)
		{
			n_paint_layer_multiselect = true;

			bool refresh = false;

			n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

			if ( nam[ 1 ] == n_posix_literal( ' ' ) )
			{
				refresh  = true;
				nam[ 1 ] = n_posix_literal( 'u' );
			} else
			if ( nam[ 1 ] == n_posix_literal( 'B' ) )
			{
				refresh  = true;
				nam[ 1 ] = n_posix_literal( 'U' );
			}

			if ( refresh ) { n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam ); }

			n_string_free( nam );
		} else
		if ( i == y )
		{
			n_paint_layer_multiselect = true;

			bool refresh = false;

			n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

			if ( nam[ 1 ] == n_posix_literal( ' ' ) )
			{
				refresh  = true;
				nam[ 1 ] = n_posix_literal( 'u' );
			} else
			if ( nam[ 1 ] == n_posix_literal( 'B' ) )
			{
				refresh  = true;
				nam[ 1 ] = n_posix_literal( 'U' );
			}

			if ( refresh ) { n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam ); }

			n_string_free( nam );
		}

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	n_win_txtbox_refresh( &n_paint_layer_txtbox );


	return;
}

void
n_paint_layer_visibility_off( int y )
{

	n_posix_char *nam = n_win_txtbox_selection_new( &n_paint_layer_txtbox );

	if ( nam[ 1 ] == n_posix_literal( 'B' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = false;
	} else
	if ( nam[ 1 ] == n_posix_literal( ' ' ) )
	{
		//
		n_paint_layer_data[ y ].visible = false;
	}
	if ( nam[ 1 ] == n_posix_literal( 'U' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = false;
	} else
	if ( nam[ 1 ] == n_posix_literal( 'u' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = false;
	}
//n_posix_debug_literal( "%s", str );

	n_win_txtbox_line_mod( &n_paint_layer_txtbox, y, nam );

	n_string_free( nam );


	n_win_txtbox_refresh( &n_paint_layer_txtbox );


	n_paint_refresh_client();


	return;
}

void
n_paint_layer_visibility_onoff( int y )
{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( n_paint_layer_txtbox.hwnd ), "%d", n_paint_layer_txtbox.select_cch_y );


	n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, y );

	if ( nam[ 1 ] == n_posix_literal( 'B' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = false;
	} else
	if ( nam[ 1 ] == n_posix_literal( ' ' ) )
	{
		nam[ 1 ] = n_posix_literal( 'B' );
		n_paint_layer_data[ y ].visible =  true;
	}
	if ( nam[ 1 ] == n_posix_literal( 'U' ) )
	{
		nam[ 1 ] = n_posix_literal( 'u' );
		n_paint_layer_data[ y ].visible = false;
	} else
	if ( nam[ 1 ] == n_posix_literal( 'u' ) )
	{
		nam[ 1 ] = n_posix_literal( 'U' );
		n_paint_layer_data[ y ].visible =  true;
	}
//n_posix_debug_literal( "%s", str );

	n_win_txtbox_line_mod( &n_paint_layer_txtbox, y, nam );

	n_string_free( nam );


	n_paint_layer_txtbox.select_cch_y = y;

	n_win_txtbox_refresh( &n_paint_layer_txtbox );


	n_paint_refresh_client();


	return;
}

void
n_paint_layer_visibility_onoff_all( bool onoff )
{

	int i = 0;
	while( 1 )
	{

		n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

		if ( onoff )
		{

			n_paint_layer_data[ i ].visible = true;


			if ( nam[ 1 ] == n_posix_literal( 'u' ) )
			{
				nam[ 1 ] = n_posix_literal( 'U' );
			} else
			if ( nam[ 1 ] == n_posix_literal( ' ' ) )
			{
				nam[ 1 ] = n_posix_literal( 'B' );
			}

			n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam );

		} else {

			n_paint_layer_data[ i ].visible = false;


			if ( nam[ 1 ] == n_posix_literal( 'U' ) )
			{
				nam[ 1 ] = n_posix_literal( 'u' );
			} else
			if ( nam[ 1 ] == n_posix_literal( 'B' ) )
			{
				nam[ 1 ] = n_posix_literal( ' ' );
			}

			n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam );

		}

		n_string_free( nam );


		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	n_win_txtbox_refresh( &n_paint_layer_txtbox );


	n_paint_refresh_client();


	return;
}

void
n_paint_layer_rename_off( void )
{

	n_paint_layer_rename_onoff = false;


	ShowWindow( n_paint_layer_rename.hwnd, SW_HIDE );


	SetFocus( hwnd_layr );
	n_win_txtbox_refresh( &n_paint_layer_txtbox );


	return;
}

void
n_paint_layer_rename_go( void )
{

	if ( n_paint_layer_rename_onoff == false )
	{

		n_paint_layer_rename_onoff = true;


		s32 linenum_osx = 0;
		if ( n_paint_layer_txtbox.style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
		{
			linenum_osx = n_paint_layer_txtbox.number_pxl_sx;// + n_paint_layer_txtbox.number_pad_pxl_sx;
		}
		linenum_osx = n_posix_max_s32( n_paint_layer_txtbox.pad_pxl_sx + linenum_osx, linenum_osx );


		s32 sc = n_paint_layer_txtbox.scroll_cch_tabbed_y * n_paint_layer_txtbox.cell_pxl_sy;

		s32 sy = n_paint_layer_txtbox.  cell_pxl_sy;
		s32 sx = n_paint_layer_txtbox.canvas_pxl_sx + 1;
		s32 tx = n_paint_layer_txtbox.   pad_pxl_sx;
		s32 ty = n_paint_layer_txtbox.   pad_pxl_sy + ( sy * n_paint_layer_rename_target ) - sc;

		sx -= linenum_osx;
		tx += linenum_osx;

		s32 m; n_win_stdsize( hwnd_layr, NULL, NULL, &m );

		tx += m;
		ty += m;
		sx += m;
		sy += m;

		n_posix_char *str = n_win_txtbox_selection_new( &n_paint_layer_txtbox );
		n_string_copy( &str[ 3 ], str );

		n_win_txtbox_line_mod( &n_paint_layer_rename, 0, str );
		n_string_free( str );

		n_win_txtbox_select_tail_set( &n_paint_layer_rename );

		n_win_move_simple( n_paint_layer_rename.hwnd, tx, ty, sx, sy, false );

		ShowWindow( n_paint_layer_rename.hwnd, SW_SHOWNA );
		SetFocus( n_paint_layer_rename.hwnd );

	} else {

		n_paint_layer_rename_onoff = false;


		n_posix_char *str = n_win_txtbox_selection_new( &n_paint_layer_rename );
		if ( N_PAINT_LAYER_CCH <= n_posix_strlen( str ) )
		{
			str[ N_PAINT_LAYER_CCH - 1 ] = N_STRING_CHAR_NUL;
		}
//n_posix_debug_literal( "%s", str );

		n_string_copy( str, n_paint_layer_data[ n_paint_layer_rename_target ].name );


		n_posix_char nam[ N_PAINT_LAYER_CCH ];
		if ( n_paint_layer_multiselect )
		{
			if ( n_paint_layer_data[ n_paint_layer_rename_target ].visible )
			{
				n_posix_sprintf_literal( nam, "[U]%s", str );
			} else {
				n_posix_sprintf_literal( nam, "[u]%s", str );
			}
		} else {
			if ( n_paint_layer_data[ n_paint_layer_rename_target ].visible )
			{
				n_posix_sprintf_literal( nam, "[B]%s", str );
			} else {
				n_posix_sprintf_literal( nam, "[ ]%s", str );
			}
		}

		n_win_txtbox_line_mod( &n_paint_layer_txtbox, n_paint_layer_rename_target, nam );


		n_string_free( str );


		ShowWindow( n_paint_layer_rename.hwnd, SW_HIDE );


		SetFocus( hwnd_layr );
		n_win_txtbox_refresh( &n_paint_layer_txtbox );


		n_bmp_free( &n_paint_bmp_name );

		n_paint_refresh_client();

	}


	return;
}

void
n_paint_layer_grabber_onoff( bool onoff )
{

	n_win_check_onoff( &n_paint_layer_chk_wholegrb, onoff );
	//n_win_check_onoff( &n_paint_layer_chk_move_grb, onoff );


	return;
}

void
n_paint_layer_grabber_move( int fy, int ty )
{

	if ( n_paint_layer_data[ ty ].visible )
	{
		n_bmp bmp = n_paint_layer_data[ fy ].bmp_grab;
		n_paint_layer_data[ fy ].bmp_grab = n_paint_layer_data[ ty ].bmp_grab;
		n_paint_layer_data[ ty ].bmp_grab = bmp;

		n_paint_bmp_data = &n_paint_layer_data[ ty ].bmp_data;
		n_paint_bmp_grab = &n_paint_layer_data[ ty ].bmp_grab;

		n_paint_grabber_selected_index = ty;

		//n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%s", n_paint_layer_data[ ty ].name );
		//n_win_statusbar_od_text( &n_paint_layer_statusbar, str, 0 );

		n_paint_layer_grabber_location( ty );

		n_win_txtbox_refresh( &n_paint_layer_txtbox );

		n_paint_refresh_client();
	}


	return;
}

void
n_paint_layer_resize( HWND hwnd, bool shade_onoff, bool is_init )
{

	s32 ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );


	n_win_txtbox_metrics_canvas( &n_paint_layer_txtbox );
//n_posix_debug_literal( " %d ", n_paint_layer_txtbox.cell_pxl_sy );


	s32 set = n_paint_layer_count + 2;

	if ( n_paint_layer_scroll_onoff )
	{
		set = n_posix_minmax( 16, n_paint_layer_count, 16 ) + 2;
	}

	s32 csy = ( n_paint_layer_txtbox.cell_pxl_sy * set ) + ( ctl * 3 );

	s32 gap = m * 2;
	s32 csx = ( ico * 5 ) + ( gap * 4 );

	s32 patch_csx = csx + m;
	s32 patch_csy = csy + m;

	n_win_set_patch( hwnd, &patch_csx, &patch_csy, 7, 7 );

	if ( shade_onoff ) { patch_csy = 0; }

	int nw = N_WIN_SET_DEFAULT;
	if ( is_init ) { nw = N_WIN_SET_NEEDPOS; }

	if ( nwin_layr.posx == -1 ) { nwin_layr.posx = nwin_tool.posx + nwin_tool.wsx + ctl; }
	if ( nwin_layr.posy == -1 ) { nwin_layr.posy = nwin_tool.posy; }

	n_win_set( hwnd, &nwin_layr, patch_csx,patch_csy, nw );

	n_win_move(  n_paint_layer_txtbox      .hwnd, 0,                 0, csx, csy-(ctl*3), true );
	nwscr_move( &n_paint_layer_scr_blend        , 0, csy - ( ctl * 1 ), csx,         ctl, true );
	nwscr_move( &n_paint_layer_scr_blur         , 0, csy - ( ctl * 2 ), csx,         ctl, true );
	n_win_move(  n_paint_layer_chk_wholegrb.hwnd, 0, csy - ( ctl * 3 ), csx,         ctl, true );
	//n_win_move(  n_paint_layer_chk_move_grb.hwnd, 0, csy - ( ctl * 4 ), csx,         ctl, true );


	return;
}

LRESULT CALLBACK
n_paint_layer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	n_win_simplemenu_xmouse( &n_paint_simplemenu, hwnd, msg );


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );


		n_win_txtbox_on_settingchange( &n_paint_layer_txtbox );

		n_win_scroller_on_settingchange( &n_paint_layer_scr_blend );
		n_win_scroller_on_settingchange( &n_paint_layer_scr_blur  );

	break;


	case WM_CREATE :


		// Global


		// Window

		n_win_init_literal( hwnd, "", "", "" );

		n_win_hwndprintf_literal( hwnd, "%s", N_PAINT_LAYER_TITLE );

		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_ONELINE;
			style = style | N_WIN_TXTBOX_STYLE_FLATBDR;

			int style_option = 0;

			n_win_txtbox_init( &n_paint_layer_rename, hwnd, style, style_option );

			n_paint_layer_on_keydown_init();
		}

		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			if ( n_paint_layer_scroll_onoff )
			{
				style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			}

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL;
			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS;
			style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM;
			style_option = style_option | N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX;

			n_win_txtbox_init( &n_paint_layer_txtbox, hwnd, style, style_option );
		}

		n_win_scroller_init_literal( &n_paint_layer_scr_blend, hwnd, "Blend" );
		n_win_scroller_init_literal( &n_paint_layer_scr_blur , hwnd, "Blur"  );


		n_win_check_zero( &n_paint_layer_chk_wholegrb );
		n_win_check_init_literal( &n_paint_layer_chk_wholegrb, hwnd, "Whole Grab", CBS_UNCHECKEDNORMAL );
		n_win_message_send( hwnd, WM_COMMAND, 0, n_paint_layer_chk_wholegrb.hwnd );

		//n_win_check_zero( &n_paint_layer_chk_move_grb );
		//n_win_check_init_literal( &n_paint_layer_chk_move_grb, hwnd, "Move between Layers", CBS_UNCHECKEDNORMAL );
		//n_win_message_send( hwnd, WM_COMMAND, 0, n_paint_layer_chk_move_grb.hwnd );

		//n_win_statusbar_od_zero( &n_paint_layer_statusbar );
		//n_win_statusbar_od_init( &n_paint_layer_statusbar, hwnd, 1 );


		n_win_simplemenu_init( &n_paint_layer_simplemenu );

		n_win_simplemenu_set( &n_paint_layer_simplemenu,  0, NULL, n_posix_literal( "[ ]Up"                  ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  1, NULL, n_posix_literal( "[ ]Down"                ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  2, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  3, NULL, n_posix_literal( "[ ]Rename"              ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  4, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  5, NULL, n_posix_literal( "[ ]All Off"             ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  6, NULL, n_posix_literal( "[ ]All On"              ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  7, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  8, NULL, n_posix_literal( "[ ]This Only"           ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  9, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu, 10, NULL, n_posix_literal( "[ ]Grabber : Move Here" ), NULL );

		n_paint_layer_simplemenu.callback      = n_win_txtbox_callback;
		n_paint_layer_simplemenu.callback_data = &n_paint_layer_txtbox;


		// Style

		//n_win_style_new  ( hwnd, N_WS_FIXEDWINDOW    );
		//n_win_sysmenu_disable( hwnd, 0,0,1, 0,1, 1, 1 );

		n_win_style_new( hwnd, WS_POPUP | WS_CAPTION );


		// Size

		n_paint_layer_resize( hwnd, n_paint_layer_shade_onoff, true );


		// Display

		ShowWindow( hwnd, SW_HIDE );

	break;


	case WM_NCLBUTTONDBLCLK :

		if ( n_paint_layer_shade_onoff )
		{
			n_paint_layer_shade_onoff = false;
		} else {
			n_paint_layer_shade_onoff =  true;
		}

		n_paint_layer_resize( hwnd, n_paint_layer_shade_onoff, false );

	break;


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
//n_win_debug_count( hwnd );
			if ( n_paint_layer_rename_onoff )
			{
				n_paint_layer_rename_off();
			}
		}

	break;


	case WM_COMMAND :
	{

		if ( (HWND) lparam == n_paint_layer_txtbox.hwnd )
		{
//n_posix_debug_literal( "%d", wparam );

			if ( wparam == WM_LBUTTONDOWN )
			{
//break;
				int y = n_paint_layer_txtbox.select_cch_y;
//n_posix_debug_literal( "%d", y );

				n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;

				if (
					( n_paint_grabber_wholegrb_onoff )
					&&
					( false == N_PAINT_GRABBER_IS_NEUTRAL() )
				)
				{
					n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;
				}


				// [!] : grabbed and edit mode returns tooltype TOOL_TYPE_PEN or so
//n_win_hwndprintf_literal( hwnd, "%d", tooltype );

				if (
//(0)&&
					( tooltype == N_PAINT_TOOL_TYPE_GRAB )
					&&
					( false == N_PAINT_GRABBER_IS_NEUTRAL() )
					&&
					( n_paint_grabber_wholegrb_onoff == false )
					&&
					( n_win_is_input( VK_SHIFT ) )
				)
				{
					int fy = n_paint_grabber_selected_index;
					int ty = y;

					n_paint_layer_grabber_move( fy, ty );
				}


				int percent = n_paint_layer_data[ y ].percent;
				if ( y == 0 ) { percent = 100; }

				n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", percent );
				n_win_refresh( n_paint_layer_scr_blend.value, true );

				n_paint_layer_scr_blend.scrollbar.unit_pos = percent;
				n_win_scrollbar_draw_always( &n_paint_layer_scr_blend.scrollbar, true );


				int blur = n_paint_layer_data[ y ].blur;

				n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", blur );
				n_win_refresh( n_paint_layer_scr_blur.value, true );

				n_paint_layer_scr_blur.scrollbar.unit_pos = blur;
				n_win_scrollbar_draw_always( &n_paint_layer_scr_blur.scrollbar, true );


				if ( y == 0 )
				{
					nwscr_enable( &n_paint_layer_scr_blend, false );
				} else {
					nwscr_enable( &n_paint_layer_scr_blend,  true );
				}


				if ( n_paint_layer_rename_onoff )
				{
					if ( n_paint_layer_rename_target != y )
					{
						n_paint_layer_rename_go();
					}
				} else {
					n_paint_layer_rename_target = y;
				}


				n_bmp_free( &n_paint_bmp_name );


				n_paint_refresh_client();

			} else
			if ( wparam == WM_LBUTTONDBLCLK )
			{
				if ( n_paint_layer_rename_onoff ) { break; }

				if ( n_paint_layer_multiselect )
				{
					// [!] : something is needed
					n_project_dialog_info( hwnd_main, n_posix_literal( "Sorry, not implemented yet." ) );
				} else {
					n_paint_layer_visibility_onoff( n_paint_layer_txtbox.select_cch_y );
				}
			} else
			if ( ( wparam == WM_MBUTTONDOWN )||( wparam == WM_RBUTTONDOWN ) )
			{
				if ( n_win_simplemenu_target != NULL )
				{
					n_win_simplemenu_hide( n_win_simplemenu_target );
				}

				n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;
				n_paint_layer_menu_target   = n_paint_layer_txtbox.select_cch_y;
			} else
			if ( wparam == WM_RBUTTONUP )
			{
//n_posix_debug_literal( "%d", n_paint_layer_txtbox.hover_cch_y );

				if ( n_paint_layer_rename_onoff ) { break; }

				if ( n_paint_layer_menu_target != n_paint_layer_txtbox.hover_cch_y ) { break; }

				if ( n_paint_layer_txtbox.hover_cch_y >= n_paint_layer_count ) { break; }
				n_win_simplemenu_show( &n_paint_layer_simplemenu, hwnd );

				n_paint_layer_menu_target = false;
			} else
			if ( wparam == WM_MBUTTONUP )
			{
				if ( n_paint_layer_rename_onoff ) { break; }

				n_paint_layer_visibility_onoff_all( false );
				n_paint_layer_visibility_onoff( n_paint_layer_txtbox.hover_cch_y );
			}// else

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( &n_paint_layer_scr_blend ) )
		{

			int y = n_paint_layer_txtbox.select_cch_y;

			s32 prev = n_paint_layer_data[ y ].percent;

			n_paint_layer_data[ y ].percent = wparam;
			n_paint_layer_data[ y ].blend   = (double) n_paint_layer_data[ y ].percent * 0.01;

			if ( prev == wparam ) { break; }

			n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", wparam );
			n_win_refresh( n_paint_layer_scr_blend.value, true );

			n_paint_layer_scr_blend.scrollbar.unit_pos = wparam;
			n_win_scrollbar_draw_always( &n_paint_layer_scr_blend.scrollbar, true );

			n_paint_refresh_client();

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( &n_paint_layer_scr_blur ) )
		{

			int y = n_paint_layer_txtbox.select_cch_y;

			s32 prev = n_paint_layer_data[ y ].blur;

			n_paint_layer_data[ y ].blur = wparam;

			if ( prev == wparam ) { break; }

			n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", wparam );
			n_win_refresh( n_paint_layer_scr_blur.value, true );

			n_paint_layer_scr_blur.scrollbar.unit_pos = wparam;
			n_win_scrollbar_draw_always( &n_paint_layer_scr_blur.scrollbar, true );

			n_paint_refresh_client();

		} else

		if ( (HWND) lparam == n_paint_layer_chk_wholegrb.hwnd )
		{

			n_paint_grabber_wholegrb_onoff = n_win_check_is_checked( &n_paint_layer_chk_wholegrb );

			n_paint_grabber_resync_auto();


			// [!] : for scroll-wheeler

			SetFocus( hwnd_layr );

		} else
/*
		if ( (HWND) lparam == n_paint_layer_chk_move_grb.hwnd )
		{

			n_paint_grabber_move_grb_onoff = n_win_check_is_checked( &n_paint_layer_chk_move_grb );

			n_paint_grabber_resync_auto();


			// [!] : for scroll-wheeler

			SetFocus( hwnd_layr );

		} else
*/
		if ( (HWND) lparam == n_paint_layer_simplemenu.hwnd )
		{

			int y = n_paint_layer_txtbox.select_cch_y;

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
				if ( y == 0 )
				{
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, ' ' );
				} else
				if ( y == ( n_paint_layer_count - 1 ) )
				{
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, 'x' );
				} else {
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, ' ' );
				}

				if (
					( N_PAINT_GRABBER_IS_NEUTRAL() )
					||
					( false == n_paint_layer_data[ y ].visible )
				)
				{
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 10, 'x' );
				} else {
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 10, ' ' );
				}
			} else
			if ( wparam == 0 )
			{
				n_paint_layer_swap_up( y );
			} else
			if ( wparam == 1 )
			{
				n_paint_layer_swap_down( y );
			} else
			if ( wparam == 2 )
			{
				//
			} else
			if ( wparam == 3 )
			{
				n_paint_layer_rename_go();
			} else
			if ( wparam == 4 )
			{
				//
			} else
			if ( wparam == 5 )
			{
				n_paint_layer_visibility_onoff_all( false );
			} else
			if ( wparam == 6 )
			{
				n_paint_layer_visibility_onoff_all(  true );
			} else
			if ( wparam == 7 )
			{
				//
			} else
			if ( wparam == 8 )
			{
				n_paint_layer_visibility_onoff_all( false );
				n_paint_layer_visibility_onoff( n_paint_layer_txtbox.select_cch_y );
			} else
			if ( wparam == 9 )
			{
				//
			} else
			if ( wparam == 10 )
			{
				int fy = n_paint_grabber_selected_index;
				int ty = n_paint_layer_txtbox.select_cch_y;

				n_paint_layer_grabber_move( fy, ty );
			}// else
		}

	}
	break;


	case WM_CLOSE :

		// [!] : for Alt + F4

		return 0;

	break;


	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	// [!] : IBEAM : Rename GUI first
 
	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_paint_layer_rename );
		if ( ret ) { return ret; }
	}

	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_paint_layer_txtbox );
		if ( ret ) { return ret; }
	}


	n_win_scroller_proc( hwnd, msg, wparam, lparam, &n_paint_layer_scr_blend );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, &n_paint_layer_scr_blur  );

	n_win_check_proc( hwnd, msg, wparam, lparam, &n_paint_layer_chk_wholegrb );
	//n_win_check_proc( hwnd, msg, wparam, lparam, &n_paint_layer_chk_move_grb );

	//n_win_statusbar_od_proc( hwnd, msg, wparam, lparam, &n_paint_layer_statusbar );

	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


