// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp.c"
#include "../nonnon/neutral/bmp/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_scroller.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_txtbox.c"


#include "../nonnon/project/macro.c"




// rc.h

#define H_LBL_RESIZE    n_paint_resizer_hgui[  0 ]
#define H_LBL_SIZE      n_paint_resizer_hgui[  1 ]
#define H_LINE          n_paint_resizer_hgui[  2 ]
#define H_LBL_COLOR     n_paint_resizer_hgui[  3 ]
#define H_PREVIEW       n_paint_resizer_hgui[  4 ]
#define H_BUTTON        n_paint_resizer_hgui[  5 ]
#define GUI_MAX                                6

#define H_INPUT_SX      ( &n_paint_resizer_htxt[  0 ] )
#define H_INPUT_SY      ( &n_paint_resizer_htxt[  1 ] )
#define TXT_MAX                                   2

#define H_CMB_RESIZE    ( &n_paint_resizer_hcmb[  0 ] )
#define H_CMB_COLOR     ( &n_paint_resizer_hcmb[  1 ] )
#define CMB_MAX                                   2

#define H_SCR_ROUND     ( &n_paint_resizer_hscr[  0 ] )
#define H_SCR_GAMMA     ( &n_paint_resizer_hscr[  1 ] )
#define H_SCR_CLRWH     ( &n_paint_resizer_hscr[  2 ] )
#define H_SCR_VIVID     ( &n_paint_resizer_hscr[  3 ] )
#define H_SCR_BLACK     ( &n_paint_resizer_hscr[  4 ] )
#define H_SCR_SHARP     ( &n_paint_resizer_hscr[  5 ] )
#define H_SCR_CTRST     ( &n_paint_resizer_hscr[  6 ] )
#define SCR_MAX                                   7




#define MSG_SIZE                    "Size"
#define MSG_RESIZE                  "Resize Option"
#define MSG_RESIZE_TOPLEFT          "Top-Left"
#define MSG_RESIZE_TILE             "Tile"
#define MSG_RESIZE_CENTER           "Center"
#define MSG_RESIZE_TRANSFORM        "Transform"
#define MSG_RESIZE_FIT_X            "Fit : Lock X"
#define MSG_RESIZE_FIT_Y            "Fit : Lock Y"
#define MSG_RESIZE_PIXELART2        "Pixelart x2"
#define MSG_RESIZE_PIXELART3        "Pixelart x3"
#define MSG_RESIZE_CEL_ART_2        "Cel Art x2"
#define MSG_ROUND                   "Round"
#define MSG_COLOR                   "Color Option"
#define MSG_COLOR_NONE              "None"
#define MSG_COLOR_GRAY              "Grayscale"
#define MSG_COLOR_MONO              "Monochrome"
#define MSG_COLOR_MASK              "Noise Removal Mask"
#define MSG_COLOR_SIZE              "Color Reduction"
#define MSG_GAMMA                   "Gamma"
#define MSG_CLRWH                   "Color Wheel"
#define MSG_VIVID                   "Vividness"
#define MSG_BLACK                   "Blackness"
#define MSG_SHARP                   "Sharpness"
#define MSG_CTRST                   "Contrast"




// window

static HWND           n_paint_resizer_hgui[ GUI_MAX ];
static n_win_scroller n_paint_resizer_hscr[ SCR_MAX ];
static n_win_combo    n_paint_resizer_hcmb[ CMB_MAX ];
static n_win_txtbox   n_paint_resizer_htxt[ TXT_MAX ];


// app

static int n_paint_resizer_round;
static int n_paint_resizer_gamma;
static int n_paint_resizer_clrwh;
static int n_paint_resizer_vivid;
static int n_paint_resizer_black;
static int n_paint_resizer_sharp;
static int n_paint_resizer_ctrst;


static bool n_paint_resizer_scroll_init = false;


static n_paint_layer *n_paint_resizer_data;




// internal
void
n_paint_resizer_main_resize( n_bmp *bmp_ret )
{

	n_bmp b;

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		n_bmp_carboncopy( n_paint_bmp_data, &b );
	} else {
		n_bmp_carboncopy( n_paint_bmp_grab, &b );
	}


	n_posix_char str_size[ 100 ];
	s32 sx,sy;

	n_win_txtbox_selection_get( H_INPUT_SX, str_size ); sx = n_posix_atoi( str_size );
	n_win_txtbox_selection_get( H_INPUT_SY, str_size ); sy = n_posix_atoi( str_size );

	if ( sx == 0 ) { sx = N_BMP_SX( &b ); }
	if ( sy == 0 ) { sy = N_BMP_SY( &b ); }


	n_posix_char *str_resize = n_win_combo_selection_get( H_CMB_RESIZE );

	if ( n_string_is_same_literal( MSG_RESIZE_PIXELART2, str_resize ) )
	{

		n_bmp_scaler_big_pixelart( &b, 2 );

	} else

	if ( n_string_is_same_literal( MSG_RESIZE_PIXELART3, str_resize ) )
	{

		n_bmp_scaler_big_pixelart( &b, 3 );

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_CEL_ART_2, str_resize ) )
	{

		n_bmp_scaler_big( &b, 2 );
		n_bmp_scaler_big( &b, 2 );

		n_bmp_flush_antialias( &b, 1.0 );
		n_bmp_flush_antialias( &b, 1.0 );
		n_bmp_flush_antialias( &b, 1.0 );
		n_bmp_flush_antialias( &b, 1.0 );

		n_bmp_scaler_lil( &b, 2 );

		n_bmp_flush_sharpen( &b, 0.5 );

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_TRANSFORM, str_resize ) )
	{

		n_bmp_resampler
		(
			&b,
			(double) sx / N_BMP_SX( &b ),
			(double) sy / N_BMP_SY( &b )
		);

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_FIT_X, str_resize ) )
	{

		double ratio = (double) sx / N_BMP_SX( &b );

		n_bmp_resampler( &b, ratio, ratio );

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_FIT_Y, str_resize ) )
	{

		double ratio = (double) sy / N_BMP_SY( &b );

		n_bmp_resampler( &b, ratio, ratio );

	} else {

		int ret = 0;

		if ( n_string_is_same_literal( MSG_RESIZE_TOPLEFT, str_resize ) )
		{
			ret = N_BMP_RESIZER_NORMAL;
		}
		if ( n_string_is_same_literal( MSG_RESIZE_TILE,    str_resize ) )
		{
			ret = N_BMP_RESIZER_TILE;
		}
		if ( n_string_is_same_literal( MSG_RESIZE_CENTER,  str_resize ) )
		{
			ret = N_BMP_RESIZER_CENTER;
		}

		u32 margin = n_bmp_white;
		if ( n_paint_layer_onoff ) { margin = n_bmp_white_invisible; }

		n_bmp_resizer( &b, sx,sy, margin, ret );

	}


	{ // Rotate

		n_bmp_matrix_rotate( &b, n_paint_resizer_round, n_bmp_white_invisible, true );

		if ( n_paint_resizer_round != 360 ) { n_paint_grabber_is_rotated = true; }

	}


	if ( bmp_ret != NULL )
	{
		n_bmp_free_fast( bmp_ret );
		n_bmp_alias( &b, bmp_ret );
	}


	return;
}

// internal
void
n_paint_resizer_main_color( n_bmp *bmp_ret )
{

	{ // Color Option

		n_posix_char *str_color = n_win_combo_selection_get( H_CMB_COLOR );

		if ( n_string_is_same_literal( MSG_COLOR_GRAY, str_color ) )
		{
			n_bmp_flush_grayscale( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_MONO, str_color ) )
		{
			n_bmp_flush_monochrome( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_MASK, str_color ) )
		{
			n_bmp_flush_reducer( bmp_ret, 10 );
			n_bmp_flush_monochrome( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_SIZE, str_color ) )
		{
			n_bmp_flush_reducer( bmp_ret, 4 );
		}// else

	}


	{ // Gamma

		// [!] : shortcut for performance

		double g = (double) n_paint_resizer_gamma / 10.0;

		if ( g == 0.0 ) { n_bmp_flush( bmp_ret, n_bmp_black ); } else
		if ( g == 2.0 ) { n_bmp_flush( bmp_ret, n_bmp_white ); } else
		if ( g != 1.0 ) { n_bmp_flush_gamma( bmp_ret, g );     }

	}


	{ // Color Wheel & Vividness

		int h = n_paint_resizer_clrwh - 128;
		int s = n_paint_resizer_vivid - 100;
		int l = 0;

		n_bmp_flush_tweaker_hsl( bmp_ret, h, s, l );

	}


	{ // Blackness

		n_bmp_flush_blackness( bmp_ret, (double) ( n_paint_resizer_black - 100 ) * 0.01 );

	}


	{ // Sharpness

		int s = n_paint_resizer_sharp - 100;


		if ( s > 0 )
		{
			n_bmp_flush_sharpen  ( bmp_ret, (double) s * 0.01 );
		} else
		if ( s < 0 )
		{
			s *= -1;
			n_bmp_flush_antialias( bmp_ret, (double) s * 0.01 );
		}

	}


	{ // Contrast

		n_bmp_flush_contrast( bmp_ret, n_paint_resizer_ctrst );

	}


	return;
}

// internal
void
n_paint_resizer_main_rotate( n_bmp *bmp )
{

	// [!] : for rotation

	s32 sx = N_BMP_SX( bmp );
	s32 sy = N_BMP_SY( bmp );

	n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );


	return;
}

// internal
void
n_paint_resizer_preview( n_bmp *bmp )
{

	if ( n_paint_layer_onoff )
	{

		if ( n_paint_grabber_wholegrb_onoff )
		{

			n_paint_layer *data = n_memory_new_closed( sizeof( n_paint_layer ) * n_paint_layer_count );
			n_bmp_layer_copy( n_paint_resizer_data, data );


			s32 bmpsx = 0;
			s32 bmpsy = 0;

			n_bmp *p_data = n_paint_bmp_data;
			n_bmp *p_grab = n_paint_bmp_grab;

			int i = 0;
			while( 1 )
			{//break;

				n_paint_bmp_data = &data[ i ].bmp_data;
				n_paint_bmp_grab = &data[ i ].bmp_grab;

				n_paint_resizer_main_resize( &data[ i ].bmp_data );
				n_paint_resizer_main_color ( &data[ i ].bmp_data );

				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{

					if ( bmpsx < N_BMP_SX( &data[ i ].bmp_data ) )
					{
						bmpsx = N_BMP_SX( &data[ i ].bmp_data );
					}

					if ( bmpsy < N_BMP_SY( &data[ i ].bmp_data ) )
					{
						bmpsy = N_BMP_SY( &data[ i ].bmp_data );
					}

				} else {

					if ( bmpsx < N_BMP_SX( &data[ i ].bmp_grab ) )
					{
						bmpsx = N_BMP_SX( &data[ i ].bmp_grab );
					}

					if ( bmpsy < N_BMP_SY( &data[ i ].bmp_grab ) )
					{
						bmpsy = N_BMP_SY( &data[ i ].bmp_grab );
					}

				}

				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}
//n_posix_debug_literal( " %d %d ", bmpsx, bmpsy );

			n_paint_bmp_data = p_data;
			n_paint_bmp_grab = p_grab;

			n_bmp_new( bmp, bmpsx, bmpsy );
			n_bmp_layercopy( data, bmp, 0,0, bmpsx,bmpsy, 0,0, false );


			n_bmp_layer_free( data );

			n_memory_free_closed( data );

		} else {

			n_bmp *p_data = n_paint_bmp_data;
			n_bmp *p_grab = n_paint_bmp_grab;

			bool found = false;

			int i = 0;
			while( 1 )
			{//break;

				if (
					( n_paint_layer_data[ i ].visible )
					&&
					( i == n_paint_layer_txtbox.select_cch_y )
				)
				{
//n_posix_debug_literal( " %d ", i );
					found = true;

					n_paint_bmp_data = &n_paint_layer_data[ i ].bmp_data;
					n_paint_bmp_grab = &n_paint_layer_data[ i ].bmp_grab;

					n_paint_resizer_main_resize( bmp );
					n_paint_resizer_main_color ( bmp );
				}

				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}

			n_paint_bmp_data = p_data;
			n_paint_bmp_grab = p_grab;

			if ( found == false )
			{
				int y = n_paint_layer_txtbox.select_cch_y;

				s32 bmpsx = N_BMP_SX( &n_paint_layer_data[ y ].bmp_data );
				s32 bmpsy = N_BMP_SY( &n_paint_layer_data[ y ].bmp_data );

				if ( false == N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					bmpsx = N_BMP_SX( &n_paint_layer_data[ y ].bmp_grab );
					bmpsy = N_BMP_SY( &n_paint_layer_data[ y ].bmp_grab );
				}

				n_bmp_new_fast( bmp, bmpsx, bmpsy );
				n_bmp_flush( bmp, n_bmp_white_invisible );
			}

		}

	} else {

		n_paint_resizer_main_resize( bmp );
		n_paint_resizer_main_color ( bmp );

	}


	return;
}

// internal
void
n_paint_resizer_background( n_bmp *bmp )
{

	s32 bmpsx = N_BMP_SX( bmp );
	s32 bmpsy = N_BMP_SY( bmp );

	n_bmp bmp_bg; n_bmp_zero( &bmp_bg ); n_bmp_new( &bmp_bg, bmpsx, bmpsy );

	n_bmp_flush( &bmp_bg, n_bmp_alpha_visible_pixel( N_PAINT_CANVAS_COLOR ) );

	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( &bmp_bg, x,y, &color );

		color = n_bmp_checker_pixel( x,y, bmpsx,bmpsy, color );

		n_bmp_ptr_set_fast( &bmp_bg, x,y, color );

		x++;
		if ( x >= bmpsx )
		{
			x = 0;

			y++;
			if ( y >= bmpsy ) { break; }
		}
	}

	n_bmp_flush_transcopy( bmp, &bmp_bg );

	n_bmp_free_fast( bmp );
	n_bmp_alias( &bmp_bg, bmp );


	return;
}

// internal
void
n_paint_resizer_go( void )
{

	if ( n_paint_layer_onoff )
	{

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{

			n_bmp *p_data = n_paint_bmp_data;

			int i = 0;
			while( 1 )
			{//break;

				n_paint_bmp_data = &n_paint_layer_data[ i ].bmp_data;

				n_paint_resizer_main_resize( &n_paint_layer_data[ i ].bmp_data );
				n_paint_resizer_main_rotate( &n_paint_layer_data[ i ].bmp_data );

				if ( n_paint_grabber_wholegrb_onoff )
				{
					if ( n_paint_layer_data[ i ].visible )
					{
						n_paint_resizer_main_color( &n_paint_layer_data[ i ].bmp_data );
					}
				} else {
					if (
						( n_paint_layer_data[ i ].visible )
						&&
						( i == n_paint_layer_txtbox.select_cch_y )
					)
					{
						n_paint_resizer_main_color( &n_paint_layer_data[ i ].bmp_data );
					}
				}


				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}

			n_paint_bmp_data = p_data;

		} else {

			n_bmp *p_grab = n_paint_bmp_grab;

			int i = 0;
			while( 1 )
			{//break;

				n_paint_bmp_grab = &n_paint_layer_data[ i ].bmp_grab;

				if ( n_paint_grabber_wholegrb_onoff )
				{
					n_paint_resizer_main_resize( &n_paint_layer_data[ i ].bmp_grab );
					n_paint_resizer_main_rotate( &n_paint_layer_data[ i ].bmp_grab );
					if ( n_paint_layer_data[ i ].visible )
					{
						n_paint_resizer_main_color ( &n_paint_layer_data[ i ].bmp_grab );
					}
				} else {
					if (
						( n_paint_layer_data[ i ].visible )
						&&
						( i == n_paint_layer_txtbox.select_cch_y )
					)
					{
						n_paint_resizer_main_resize( &n_paint_layer_data[ i ].bmp_grab );
						n_paint_resizer_main_rotate( &n_paint_layer_data[ i ].bmp_grab );
						n_paint_resizer_main_color ( &n_paint_layer_data[ i ].bmp_grab );
					}
				}


				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}

			n_paint_bmp_grab = p_grab;

		}

	} else {

		if ( grabber )
		{

			n_bmp b; n_bmp_zero( &b );

			n_paint_resizer_main_resize( &b );
			n_paint_resizer_main_rotate( &b );
			n_paint_resizer_main_color ( &b );

			n_paint_grabber_select( &b, true );

			n_bmp_free_fast( &b );

		} else {

			n_paint_resizer_main_resize( n_paint_bmp_data );
			n_paint_resizer_main_rotate( n_paint_bmp_data );
			n_paint_resizer_main_color ( n_paint_bmp_data );

		}

	}


	n_paint_refresh_all();

	n_paint_title();


	return;
}

// internal
void
n_paint_resizer_inputfield_set( void )
{

	s32 sx,sy;


	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		sx = N_BMP_SX( n_paint_bmp_data );
		sy = N_BMP_SY( n_paint_bmp_data );
	} else {
		sx = N_BMP_SX( n_paint_bmp_grab );
		sy = N_BMP_SY( n_paint_bmp_grab );
	}


	n_posix_char str_sx[ 100 ];
	n_posix_char str_sy[ 100 ];

	n_posix_sprintf_literal( str_sx, "%ld", sx );
	n_posix_sprintf_literal( str_sy, "%ld", sy );

	n_win_txtbox_line_set( H_INPUT_SX, 0, str_sx );
	n_win_txtbox_line_set( H_INPUT_SY, 0, str_sy );

	n_win_txtbox_select_tail_set( H_INPUT_SX );
	n_win_txtbox_select_tail_set( H_INPUT_SY );


	return;
}
void
n_paint_resizer_on_size( HWND hwnd, int nwin, bool redraw )
{

	s32 ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );


	s32 dpi   = n_win_dpi( hwnd );
	s32 scale = dpi / 96;


	s32 csy = ( ctl * 12 );
	s32 csx = (double) csy * sqrt( 2 );


	s32 patch_csx = csx + m;
	s32 patch_csy = csy + m;

	n_win_set_patch( hwnd, &patch_csx, &patch_csy, 7, 7 );

	n_win_set( hwnd, NULL, patch_csx + patch_csy,patch_csy, nwin );


	s32 btnsx = csx;
	s32 sx1_2 = csx / 2;
	s32 sx1_4 = csx / 4;
	s32 sx3_4 = csx / 4 * 3;
	s32 cmbsx = csx - sx1_2;
	s32 inpsx = csx - sx3_4;
	s32 ln_sx = csx - m;

	s32 x = scale;

	if ( scale != 1 ) { btnsx -= scale; }

	//if ( dpi == 96 )
	{
		csx--;
		cmbsx--;
		inpsx--;
	}

	n_win_move      ( H_LBL_RESIZE,         x,ctl* 0, sx1_2,ctl, redraw );
	n_win_combo_move( H_CMB_RESIZE,     sx1_2,ctl* 0, cmbsx,csy,   true );
	n_win_move      ( H_LBL_SIZE,           x,ctl* 1, sx1_2,ctl, redraw );
	n_win_move      ( H_INPUT_SX->hwnd, sx1_2,ctl* 1, sx1_4,ctl, redraw );
	n_win_move      ( H_INPUT_SY->hwnd, sx3_4,ctl* 1, inpsx,ctl, redraw );
	nwscr_move      ( H_SCR_ROUND,          x,ctl* 2,   csx,ctl, redraw );
	n_win_move      ( H_LINE,               x,ctl* 3, ln_sx,ctl, redraw );
	n_win_move      ( H_LBL_COLOR,          x,ctl* 4, sx1_2,ctl, redraw );
	n_win_combo_move( H_CMB_COLOR,      sx1_2,ctl* 4, cmbsx,csy,   true );
	nwscr_move      ( H_SCR_GAMMA,          x,ctl* 5,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_CLRWH,          x,ctl* 6,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_VIVID,          x,ctl* 7,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_BLACK,          x,ctl* 8,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_SHARP,          x,ctl* 9,   csx,ctl, redraw );
	nwscr_move      ( H_SCR_CTRST,          x,ctl*10,   csx,ctl, redraw );
	n_win_move      ( H_BUTTON,             x,ctl*11, btnsx,ctl, redraw );

	s32 pv_x = patch_csx;
	s32 pv   = patch_csy - m;
	n_win_move      ( H_PREVIEW,         pv_x,     0,     pv,pv, redraw );


	return;
}

void
n_paint_resizer_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );


		n_win_stdfont_init( n_paint_resizer_hgui, GUI_MAX );


		n_win_refresh( H_LBL_RESIZE, true );
		n_win_combo_on_settingchange( H_CMB_RESIZE );

		n_win_refresh( H_LBL_SIZE, true );

		n_win_txtbox_on_settingchange( H_INPUT_SX );
		n_win_txtbox_on_settingchange( H_INPUT_SY );

		n_win_scroller_on_settingchange( H_SCR_ROUND );

		n_win_refresh( H_LINE     , true );
		n_win_refresh( H_LBL_COLOR, true );

		n_win_combo_on_settingchange( H_CMB_COLOR );

		n_win_scroller_on_settingchange( H_SCR_GAMMA );
		n_win_scroller_on_settingchange( H_SCR_CLRWH );
		n_win_scroller_on_settingchange( H_SCR_VIVID );
		n_win_scroller_on_settingchange( H_SCR_BLACK );
		n_win_scroller_on_settingchange( H_SCR_SHARP );
		n_win_scroller_on_settingchange( H_SCR_CTRST );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BUTTON );

	break;


	} // switch


}
 
LRESULT CALLBACK
n_paint_resizer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND         target_input =  NULL;
	static n_win_combo *target_combo =  NULL;
	static UINT         target_timer =     0;

	static bool         preview_drag_onoff = 0;
	static s32          preview_x          = 0;
	static s32          preview_y          = 0;
	static POINT        preview_cursor_cur;
	static POINT        preview_cursor_prv;
	static n_bmp        preview_bmp;

	static s32          preview_pfx = -1;
	static s32          preview_pfy = -1;
	static s32          preview_ptx = -1;
	static s32          preview_pty = -1;

	static bool         is_cancelled = true;


	n_paint_resizer_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_combo_zero( H_CMB_RESIZE );
		n_win_combo_zero( H_CMB_COLOR  );

		n_win_scroller_zero( H_SCR_ROUND );
		n_win_scroller_zero( H_SCR_GAMMA );
		n_win_scroller_zero( H_SCR_CLRWH );
		n_win_scroller_zero( H_SCR_VIVID );
		n_win_scroller_zero( H_SCR_BLACK );
		n_win_scroller_zero( H_SCR_SHARP );
		n_win_scroller_zero( H_SCR_CTRST );

		n_win_txtbox_zero( H_INPUT_SX );
		n_win_txtbox_zero( H_INPUT_SY );

		n_paint_resizer_scroll_init = true;

		n_bmp_zero( &preview_bmp );
		preview_x = preview_y = 0;

		preview_pfx = -1;
		preview_pfy = -1;
		preview_ptx = -1;
		preview_pty = -1;


		// Window

		n_win_init_literal( hwnd, "Resizer", "", "" );

		n_win_gui_literal( hwnd, LABEL,   MSG_RESIZE, &H_LBL_RESIZE );
		n_win_gui_literal( hwnd, LABEL,     MSG_SIZE, &H_LBL_SIZE   );
		n_win_gui_literal( hwnd, CANVAS,          "", &H_LINE       );
		n_win_gui_literal( hwnd, LABEL,    MSG_COLOR, &H_LBL_COLOR  );
		n_win_gui_literal( hwnd, FBTN,            "", &H_BUTTON     );
		n_win_gui_literal( hwnd, CANVAS,          "", &H_PREVIEW    );

		n_win_text_set( H_BUTTON, n_project_string_go );

		n_win_combo_init( H_CMB_RESIZE, hwnd );
		n_win_combo_init( H_CMB_COLOR , hwnd );

		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_ONELINE_HCENTER;
			option |= N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL;

			n_win_txtbox_init( H_INPUT_SX, hwnd, style, option );
			n_win_txtbox_init( H_INPUT_SY, hwnd, style, option );

			n_win_property_init_literal( H_INPUT_SX->hwnd, "Number", true );
			n_win_property_init_literal( H_INPUT_SY->hwnd, "Number", true );
		}

		n_win_scroller_init_literal( H_SCR_ROUND, hwnd, MSG_ROUND );
		n_win_scroller_init_literal( H_SCR_GAMMA, hwnd, MSG_GAMMA );
		n_win_scroller_init_literal( H_SCR_CLRWH, hwnd, MSG_CLRWH );
		n_win_scroller_init_literal( H_SCR_VIVID, hwnd, MSG_VIVID );
		n_win_scroller_init_literal( H_SCR_BLACK, hwnd, MSG_BLACK );
		n_win_scroller_init_literal( H_SCR_SHARP, hwnd, MSG_SHARP );
		n_win_scroller_init_literal( H_SCR_CTRST, hwnd, MSG_CTRST );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		n_project_defaultbutton( H_BUTTON );
		SetFocus( H_BUTTON );

		n_win_iconbutton_init( hwnd, H_BUTTON );


		n_win_stdfont_init( n_paint_resizer_hgui, GUI_MAX );


		// Size

		n_paint_resizer_on_size( hwnd, N_WIN_SET_CENTERING, false );


		// Init

		n_paint_resizer_inputfield_set();


		n_txt_set_literal( &H_CMB_RESIZE->txt, 0, MSG_RESIZE_TOPLEFT   );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 1, MSG_RESIZE_TILE      );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 2, MSG_RESIZE_CENTER    );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 3, MSG_RESIZE_TRANSFORM );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 4, MSG_RESIZE_FIT_X     );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 5, MSG_RESIZE_FIT_Y     );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 6, MSG_RESIZE_PIXELART2 );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 7, MSG_RESIZE_PIXELART3 );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 8, MSG_RESIZE_CEL_ART_2 );


		n_win_combo_selection_set_by_string_literal( H_CMB_RESIZE, MSG_RESIZE_CENTER );


		n_txt_set_literal( &H_CMB_COLOR->txt, 0, MSG_COLOR_NONE );
		n_txt_set_literal( &H_CMB_COLOR->txt, 1, MSG_COLOR_GRAY );
		n_txt_set_literal( &H_CMB_COLOR->txt, 2, MSG_COLOR_MONO );
		n_txt_set_literal( &H_CMB_COLOR->txt, 3, MSG_COLOR_MASK );
		n_txt_set_literal( &H_CMB_COLOR->txt, 4, MSG_COLOR_SIZE );

		n_win_combo_selection_set_by_string_literal( H_CMB_COLOR, MSG_COLOR_NONE );


		n_paint_resizer_round = 360;
		n_paint_resizer_gamma =  10;
		n_paint_resizer_clrwh = 128;
		n_paint_resizer_vivid = 100;
		n_paint_resizer_black = 100;
		n_paint_resizer_sharp = 100;
		n_paint_resizer_ctrst =   0;

		n_win_scroller_scroll_parameter( H_SCR_ROUND, 1, 10, 720, n_paint_resizer_round, true );
		n_win_scroller_scroll_parameter( H_SCR_GAMMA, 1, 10,  20, n_paint_resizer_gamma, true );
		n_win_scroller_scroll_parameter( H_SCR_CLRWH, 1, 10, 256, n_paint_resizer_clrwh, true );
		n_win_scroller_scroll_parameter( H_SCR_VIVID, 1, 10, 200, n_paint_resizer_vivid, true );
		n_win_scroller_scroll_parameter( H_SCR_BLACK, 1, 10, 200, n_paint_resizer_black, true );
		n_win_scroller_scroll_parameter( H_SCR_SHARP, 1, 10, 200, n_paint_resizer_sharp, true );
		n_win_scroller_scroll_parameter( H_SCR_CTRST, 1, 10, 256, n_paint_resizer_ctrst, true );


		if ( n_paint_layer_onoff )
		{
			if ( n_paint_grabber_wholegrb_onoff )
			{
				n_paint_resizer_data = n_memory_new_closed( sizeof( n_paint_layer ) * n_paint_layer_count );
				n_bmp_layer_copy( n_paint_layer_data, n_paint_resizer_data );
			}
		}

		n_paint_resizer_preview( &preview_bmp );
		n_paint_resizer_background( &preview_bmp );


		// Display

		n_paint_resizer_scroll_init = false;

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, false );
		EnableWindow( hwnd_layr, false );
		EnableWindow( hwnd_main, false );

		n_paint_refresh_client();

	break;


	case WM_SIZE :

		// [Needed] : non-DWM : scrollers disappear when combo is closed

		n_paint_resizer_on_size( hwnd, N_WIN_SET_DEFAULT, true );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else

		if ( wparam == N_PAINT_KEY_D )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_COMMAND :
	{
//break;
		HWND h = (HWND) lparam;


		bool preview_refresh = false;


		if ( h == H_INPUT_SX->hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open( hwnd, H_INPUT_SX->hwnd );
			}

		} else

		if ( h == H_INPUT_SY->hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open( hwnd, H_INPUT_SY->hwnd );
			}

		} else

		if ( h == n_win_combo_hwnd( H_CMB_RESIZE ) )
		{
//n_win_hwndprintf_literal( hwnd, " %d ", wparam );
//break;
			if ( ( wparam >= WM_MOUSEFIRST )&&( wparam <= WM_MOUSELAST ) ) { break; }


			EnableWindow( H_LBL_SIZE      , true );
			EnableWindow( H_INPUT_SX->hwnd, true );
			EnableWindow( H_INPUT_SY->hwnd, true );

			EnableWindow( H_LBL_COLOR, true );
			EnableWindow( n_win_combo_hwnd( H_CMB_COLOR ), true );
			nwscr_enable( H_SCR_ROUND, true );
			nwscr_enable( H_SCR_GAMMA, true );
			nwscr_enable( H_SCR_CLRWH, true );
			nwscr_enable( H_SCR_VIVID, true );
			nwscr_enable( H_SCR_BLACK, true );
			nwscr_enable( H_SCR_SHARP, true );
			nwscr_enable( H_SCR_CTRST, true );


			n_posix_char *str = n_win_combo_selection_get( H_CMB_RESIZE );

			n_win_txtbox_grayed( H_INPUT_SX, false );
			n_win_txtbox_grayed( H_INPUT_SY, false );

			if ( n_string_is_same_literal( MSG_RESIZE_FIT_X,    str ) )
			{
				EnableWindow( H_INPUT_SY->hwnd, false );
				n_win_txtbox_grayed( H_INPUT_SY,  true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_FIT_Y,    str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, false );
				n_win_txtbox_grayed( H_INPUT_SX,  true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_PIXELART2, str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, false );
				EnableWindow( H_INPUT_SY->hwnd, false );

				n_win_txtbox_grayed( H_INPUT_SX,  true );
				n_win_txtbox_grayed( H_INPUT_SY,  true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_PIXELART3, str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, false );
				EnableWindow( H_INPUT_SY->hwnd, false );

				n_win_txtbox_grayed( H_INPUT_SX,  true );
				n_win_txtbox_grayed( H_INPUT_SY,  true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_CEL_ART_2, str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, false );
				EnableWindow( H_INPUT_SY->hwnd, false );

				n_win_txtbox_grayed( H_INPUT_SX,  true );
				n_win_txtbox_grayed( H_INPUT_SY,  true );
			}// else

			preview_refresh = true;

		} else
		if ( h == n_win_combo_hwnd( H_CMB_COLOR ) )
		{

			if ( ( wparam >= WM_MOUSEFIRST )&&( wparam <= WM_MOUSELAST ) ) { break; }

			preview_refresh = true;

		} else

		if ( h == H_BUTTON )
		{

			is_cancelled = false;

			n_paint_resizer_go();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_ROUND ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_round == wparam )
			)
			{
				break;
			}
//n_posix_debug_literal( "%d %d", n_paint_resizer_round, wparam );

			if ( n_paint_resizer_scroll_init == false ) { preview_refresh = true; }


			n_paint_resizer_round = wparam;


#ifdef UNICODE
			const n_posix_char *str_degree = L"\x00b0";
#else // #define UNICODE
			const n_posix_char *str_degree = "";
#endif // #define UNICODE

			n_win_hwndprintf_literal( H_SCR_ROUND->value, "%d%s", n_paint_resizer_round - 360, str_degree );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_GAMMA ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_gamma == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == false ) { preview_refresh = true; }


			n_paint_resizer_gamma = wparam;

			n_win_hwndprintf_literal( H_SCR_GAMMA->value, "%1.1f", (double) n_paint_resizer_gamma / 10.0 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_CLRWH ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_clrwh == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == false ) { preview_refresh = true; }


			n_paint_resizer_clrwh = wparam;

			n_win_hwndprintf_literal( H_SCR_CLRWH->value, "%d", n_paint_resizer_clrwh - 128 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_VIVID ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_vivid == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == false ) { preview_refresh = true; }


			n_paint_resizer_vivid = wparam;

			n_win_hwndprintf_literal( H_SCR_VIVID->value, "%d", n_paint_resizer_vivid - 100 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_BLACK ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_black == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == false ) { preview_refresh = true; }


			n_paint_resizer_black = wparam;

			n_win_hwndprintf_literal( H_SCR_BLACK->value, "%d", n_paint_resizer_black - 100 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_SHARP ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_sharp == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == false ) { preview_refresh = true; }


			n_paint_resizer_sharp = wparam;

			n_win_hwndprintf_literal( H_SCR_SHARP->value, "%d", n_paint_resizer_sharp - 100 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_CTRST ) )
		{

			if (
				( n_paint_resizer_scroll_init == false )
				&&
				( n_paint_resizer_ctrst == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == false ) { preview_refresh = true; }


			n_paint_resizer_ctrst = wparam;

			n_win_hwndprintf_literal( H_SCR_CTRST->value, "%d", n_paint_resizer_ctrst );

		}// else


		if ( preview_refresh )
		{
//static int i = 0; n_win_hwndprintf_literal( hwnd, " %d ", i ); i++;

			preview_pfx = -1;
			preview_pfy = -1;
			preview_ptx = -1;
			preview_pty = -1;

			n_paint_resizer_preview( &preview_bmp );
			n_paint_resizer_background( &preview_bmp );

			n_win_refresh( H_PREVIEW, true );

		}

	}
	break;


	case WM_CLOSE :

		if ( is_cancelled )
		{
			if ( n_paint_layer_onoff )
			{
				if ( n_paint_grabber_wholegrb_onoff )
				{
					n_bmp_layer_free( n_paint_resizer_data );
					n_memory_free_closed( n_paint_resizer_data );
				}
			}
		}


		EnableWindow( hwnd_tool, true );
		EnableWindow( hwnd_layr, true );
		EnableWindow( hwnd_main, true );

		ShowWindow( hwnd, SW_HIDE );


		n_win_inputpopup_silent_onoff = true;
		n_win_inputpopup_autoclose();

		n_win_property_exit_literal( H_INPUT_SX->hwnd, "Number" );
		n_win_property_exit_literal( H_INPUT_SY->hwnd, "Number" );


		n_win_stdfont_exit( n_paint_resizer_hgui, GUI_MAX );

		n_win_combo_silent = true;
		n_win_combo_exit( H_CMB_RESIZE );

		n_win_combo_silent = true;
		n_win_combo_exit( H_CMB_COLOR  );

		n_win_scroller_exit( H_SCR_ROUND );
		n_win_scroller_exit( H_SCR_GAMMA );
		n_win_scroller_exit( H_SCR_CLRWH );
		n_win_scroller_exit( H_SCR_VIVID );
		n_win_scroller_exit( H_SCR_BLACK );
		n_win_scroller_exit( H_SCR_SHARP );
		n_win_scroller_exit( H_SCR_CTRST );


		n_bmp_free_fast( &preview_bmp );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	case WM_TIMER :

		if ( wparam == target_timer )
		{
			n_win_timer_exit( hwnd, target_timer );

			target_input = NULL;
			target_combo = NULL;

			H_SCR_ROUND->scrollbar.stop_onoff = false;
			H_SCR_GAMMA->scrollbar.stop_onoff = false;
			H_SCR_CLRWH->scrollbar.stop_onoff = false;
			H_SCR_VIVID->scrollbar.stop_onoff = false;
			H_SCR_BLACK->scrollbar.stop_onoff = false;
			H_SCR_SHARP->scrollbar.stop_onoff = false;
			H_SCR_CTRST->scrollbar.stop_onoff = false;
		}

	break;


	case WM_NCLBUTTONDOWN :

		SetFocus( hwnd );

	break;

	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :

		SetFocus( hwnd );


		if ( n_win_is_hovered( H_PREVIEW ) )
		{

			if ( preview_drag_onoff == false )
			{
				preview_drag_onoff = true;

				SetCapture( hwnd );

				GetCursorPos( &preview_cursor_prv );

				if ( n_win_is_hovered( H_PREVIEW ) )
				{
					n_win_cursor_add( NULL, IDC_SIZEALL );
				} else {
					n_win_cursor_add( NULL, IDC_ARROW   );
				}

			}

		}

	break;

	case WM_LBUTTONUP :
	case WM_MBUTTONUP :
	case WM_RBUTTONUP :

		if ( preview_drag_onoff )
		{
			preview_drag_onoff = false;

			ReleaseCapture();
		}

	break;

	case WM_MOUSEMOVE :
	{

		if ( n_win_is_hovered( H_PREVIEW ) )
		{
			n_win_cursor_add( NULL, IDC_SIZEALL );
		} else {
			// [!] : reserved for input fields
			//n_win_cursor_add( NULL, IDC_ARROW   );
		}

		if ( preview_drag_onoff == false ) { break; }


		GetCursorPos( &preview_cursor_cur );

		preview_x += preview_cursor_prv.x - preview_cursor_cur.x;
		preview_y += preview_cursor_prv.y - preview_cursor_cur.y;

		preview_cursor_prv = preview_cursor_cur;


		n_win_refresh( H_PREVIEW, false );

	}
	break;

	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( H_PREVIEW != di->hwndItem ) { break; }


		s32 bsx = N_BMP_SX( &preview_bmp );
		s32 bsy = N_BMP_SY( &preview_bmp );

		s32 psx,psy; n_win_size( H_PREVIEW, &psx, &psy );

		s32 preview_fx = 0;
		s32 preview_fy = 0;
		s32 preview_tx = 0;
		s32 preview_ty = 0;

		if ( bsx < psx )
		{
			preview_tx = ( psx - bsx ) / 2;
		} else {
			if ( preview_x < 0 )
			{
				preview_x = 0;
			} else
			if ( preview_x > ( bsx - psx ) )
			{
				preview_x = ( bsx - psx );
			}

			preview_fx = preview_x;
		}

		if ( bsy < psy )
		{
			preview_ty = ( psy - bsy ) / 2;
		} else {
			if ( preview_y < 0 )
			{
				preview_y = 0;
			} else
			if ( preview_y > ( bsy - psy ) )
			{
				preview_y = ( bsy - psy );
			}

			preview_fy = preview_y;
		}
//n_win_hwndprintf_literal( hwnd, " %d %d ", preview_x, preview_y );

		if (
			( ( preview_pfx == preview_fx )&&( preview_pfy == preview_fy ) )
			&&
			( ( preview_ptx == preview_tx )&&( preview_pty == preview_ty ) )
		)
		{
			 break;
		}

		preview_pfx = preview_fx;
		preview_pfy = preview_fy;
		preview_ptx = preview_tx;
		preview_pty = preview_ty;

		n_gdi_doublebuffer_32bpp_simple_init( H_PREVIEW, psx, psy );

		n_gdi_doublebuffer_fill( &n_gdi_doublebuffer_32bpp_instance, N_PAINT_CANVAS_COLOR );

		n_bmp_transcopy
		(
			&preview_bmp,
			&n_gdi_doublebuffer_32bpp_instance.bmp,
			preview_fx,preview_fy,bsx,bsy,
			preview_tx,preview_ty
		);

		n_draw_frame( &n_gdi_doublebuffer_32bpp_instance.bmp, 0,0,psx,psy, n_bmp_white, n_bmp_black );

		n_gdi_doublebuffer_32bpp_simple_exit();

	}
	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_LINE, PS_DOT );


	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BUTTON );


	n_win_inputpopup_proc_light( hwnd, msg, wparam, lparam, H_INPUT_SX->hwnd );
	n_win_inputpopup_proc_light( hwnd, msg, wparam, lparam, H_INPUT_SY->hwnd );

	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );

	if ( target_input == NULL )
	{
		if ( n_win_inputpopup_target != NULL )
		{
			target_input = n_win_inputpopup_target;

			H_SCR_ROUND->scrollbar.stop_onoff = true;
			H_SCR_GAMMA->scrollbar.stop_onoff = true;
			H_SCR_CLRWH->scrollbar.stop_onoff = true;
			H_SCR_VIVID->scrollbar.stop_onoff = true;
			H_SCR_BLACK->scrollbar.stop_onoff = true;
			H_SCR_SHARP->scrollbar.stop_onoff = true;
			H_SCR_CTRST->scrollbar.stop_onoff = true;
		}
	} else {
		if ( n_win_inputpopup_target == NULL )
		{
			if ( target_timer == 0 ) { target_timer = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, target_timer, 200 );
		}
	}


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, H_CMB_RESIZE );
	n_win_combo_proc( hwnd, msg, &wparam, &lparam, H_CMB_COLOR  );

	if ( target_combo == NULL )
	{
		if ( n_win_combo_target != NULL )
		{
			target_combo = n_win_combo_target;

			H_SCR_ROUND->scrollbar.stop_onoff = true;
			H_SCR_GAMMA->scrollbar.stop_onoff = true;
			H_SCR_CLRWH->scrollbar.stop_onoff = true;
			H_SCR_VIVID->scrollbar.stop_onoff = true;
			H_SCR_BLACK->scrollbar.stop_onoff = true;
			H_SCR_SHARP->scrollbar.stop_onoff = true;
			H_SCR_CTRST->scrollbar.stop_onoff = true;
		}
	} else {
		if ( n_win_combo_target == NULL )
		{
			if ( target_timer == 0 ) { target_timer = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, target_timer, 200 );
		}
	}

	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_ROUND );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_GAMMA );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_CLRWH );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_VIVID );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_BLACK );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_SHARP );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_CTRST );

	{
		int ret = 0;
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, H_INPUT_SX );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, H_INPUT_SY );
		if ( ret ) { return ret; }
	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_LBL_RESIZE
#undef H_LBL_SIZE
#undef H_LINE
#undef H_LBL_COLOR
#undef H_PREVIEW
#undef H_BUTTON
#undef GUI_MAX

#undef H_INPUT_SX
#undef H_INPUT_SY
#undef TXT_MAX

#undef H_CMB_RESIZE
#undef H_CMB_COLOR
#undef CMB_MAX

#undef H_SCR_ROUND
#undef H_SCR_GAMMA
#undef H_SCR_CLRWH
#undef H_SCR_VIVID
#undef H_SCR_BLACK
#undef H_SCR_SHARP
#undef H_SCR_CTRST
#undef SCR_MAX


#undef MSG_SIZE
#undef MSG_RESIZE
#undef MSG_RESIZE_TOPLEFT
#undef MSG_RESIZE_TILE
#undef MSG_RESIZE_CENTER
#undef MSG_RESIZE_TRANSFORM
#undef MSG_RESIZE_FIT_X
#undef MSG_RESIZE_FIT_Y
#undef MSG_RESIZE_PIXELART2
#undef MSG_RESIZE_PIXELART3
#undef MSG_RESIZE_CEL_ART_2
#undef MSG_ROUND
#undef MSG_COLOR
#undef MSG_COLOR_NONE
#undef MSG_COLOR_GRAY
#undef MSG_COLOR_MONO
#undef MSG_COLOR_MASK
#undef MSG_COLOR_SIZE
#undef MSG_GAMMA
#undef MSG_CLRWH
#undef MSG_VIVID
#undef MSG_BLACK
#undef MSG_SHARP
#undef MSG_CTRST

