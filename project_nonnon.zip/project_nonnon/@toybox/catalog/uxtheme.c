



#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/win_iconbutton.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const n_posix_char *iconname = n_posix_literal( "../../orangecat/rc/orangecat.multi.ico" );


	const int guimax = 9;
	const int txtmax = 5;
	const int icomax = 4;


	const int sx = 40;
	const int sy = 40;


	static HWND hgui[ 9 ];
	static HWND hgui_ico;


	static HICON ico;


	int i;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		i = 0;
		while( 1 )
		{

			n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, hgui[ i ] );

			i++;
			if ( i >= guimax ) { break; }
		}

	break;


	case WM_CREATE :


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,240, N_WIN_SET_CENTERING );


		// Controls

		i = 0;
		while( 1 )
		{

			if ( i == 0 )
			{
				n_win_gui_literal( hwnd, BUTTON, n_posix_literal( "Normal" ), &hgui[ i ] );
			} else
			if ( i == 1 )
			{
				n_win_gui_literal( hwnd, BUTTON, n_posix_literal( "Hovered" ), &hgui[ i ] );
			} else
			if ( i == 2 )
			{
				n_win_gui_literal( hwnd, BUTTON, n_posix_literal( "Focused" ), &hgui[ i ] );
			} else
			if ( i == 3 )
			{
				n_win_gui_literal( hwnd, BUTTON, n_posix_literal( "Pressed" ), &hgui[ i ] );
			} else
			if ( i == 4 )
			{
				n_win_gui_literal( hwnd, BUTTON, n_posix_literal( "Disabled" ), &hgui[ i ] );
			}// else

			n_win_move_simple( hgui[ i ], 0, i * sy, 200,sy, true );


			i++;
			if ( i >= txtmax ) { break; }
		}


		i = 0;
		while( 1 )
		{

			n_win_gui_literal( hwnd, ICOBTN, NULL, &hgui[ txtmax + i ] );

			n_win_move_simple( hgui[ txtmax + i ], sx * i,sy * txtmax, sx,sy, true );

			i++;
			if ( i >= icomax ) { break; }
		}

		//n_win_icon_set( hgui[ txtmax + icomax + 1 ], ico );

		n_win_gui_literal( hwnd, ICOBTN, iconname, &hgui_ico );
		n_win_move_simple( hgui_ico, sx * i,sy * txtmax, sx,sy, true );


		ico = n_win_icon_init( iconname, 0, N_WIN_ICON_INIT_OPTION_DEFAULT );

		i = 0;
		while( 1 )
		{

			n_win_iconbutton_init( hwnd, hgui[ i ] );

			if ( i >= txtmax )
			{
				n_win_icon_set( hgui[ i ], ico );
			}

			i++;
			if ( i >= guimax ) { break; }
		}

		n_win_icon_set( hgui[ guimax ], ico );


		// Flavor

		n_win_style_add( hgui[ 3 ], BS_PUSHLIKE );

		SetFocus( hgui[          2 ] );
		SetFocus( hgui[ txtmax + 1 ] );

		// [!] : see nonnon/win32/win_iconbutton.c : n_win_iconbutton_draw()
		n_win_property_set_literal( hgui[ txtmax + 2 ], "DrawState", true );

		EnableWindow( hgui[          4 ], false );
		EnableWindow( hgui[ txtmax + 2 ], false );
		EnableWindow( hgui[ txtmax + 3 ], false );

		EnableWindow( hgui_ico, false );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_icon_exit( ico );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	i = 0;
	while( 1 )
	{

		n_win_iconbutton_proc( hwnd, msg, wparam, lparam, hgui[ i ] );

		i++;
		if ( i >= guimax ) { break; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

