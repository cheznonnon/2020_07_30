// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_catpad_string_remove_newline( const n_posix_char *arg, n_posix_char *ret )
{

	if ( n_string_error( arg, ret ) ) { return; }


	n_string_copy( arg, ret );


	size_t len = n_posix_strlen( ret );
	if ( len == 0 ) { return; }


	// [Mechanism]
	//
	//	CRLF : CR LF => -- CR => -- --  => return
	//	CR   : -- CR =>   N/A => -- CR  => return
	//	LF   : -- LF => -- -- => return

	if ( ret[ len - 1 ] == N_STRING_CHAR_LF )
	{

		n_string_terminate( ret, len - 1 );

		len--;
		if ( len <= 0 ) { return; }
	}

	if ( ret[ len - 1 ] == N_STRING_CHAR_CR )
	{
		n_string_terminate( ret, len - 1 );
	}


	return;
}

void
n_catpad_ntxt_binary2text( n_txt *txt )
{

	// [!] : ASCII-based conversion


	n_txt ret; n_txt_zero( &ret ); n_txt_new( &ret );

	u8 *p = txt->stream;

	size_t i = 0;
	while( 1 )
	{

		// [!] : this length will be wordwrap

		n_posix_char str[ 500 + 1 ];

		size_t ii = 0;
		while( 1 )
		{

			str[ ii ] = p[ i ];

			if ( false == n_string_is_ascii( str, ii ) )
			{
				str[ ii ] = N_STRING_CHAR_SPACE;
			}

			i++; ii++;
			if ( i  >= txt->byte ) { break; }
			if ( ii >= 500       ) { break; }

		}
		str[ ii ] = N_STRING_CHAR_NUL;


		n_txt_add( &ret, ret.sy, str );


		i++;
		if ( i >= txt->byte ) { break; }
	}

	n_txt_free( txt );
	n_txt_alias( &ret, txt );

	n_txt_stream( txt );

	n_txt_del( txt, 0 );


	txt->newline  = N_TXT_NEWLINE_BINARY;
	txt->readonly = N_TXT_READONLY_ON;


	return;
}

void
n_catpad_ntxt_copy( const n_txt *f, n_txt *t )
{

	n_txt_free( t );
	n_txt_new ( t );


	size_t i = 0;
	while( 1 )
	{

		n_txt_add( t, i, f->line[ i ] );

		i++;
		if ( i >= f->sy ) { break; }
	}

	n_txt_stream( t );


	return;
}

void
n_catpad_ntxt_dump( n_txt *txt, const n_posix_char *fname )
{

	u8     *p;
	size_t  byte;


	{

		FILE *fp = n_posix_fopen_read( fname );
		if ( fp == NULL ) { return; }

		byte = n_posix_stat_size( fname );
		p    = n_memory_new_closed( byte );

		n_posix_fread( p, byte, 1, fp );

		n_posix_fclose( fp );

	}


	// #1 : [address(8) + space(1)] + [( space(1) + hex(2) ) * 16] + [CRLF(2)] + [NUL(1)]
	// #2 : [  space(8) + space(1)] + [( space(1) + hex(2) ) * 16] + [CRLF(2)] + [NUL(1)]

	n_posix_char line_0[ ( 8 + 1 ) + ( ( 1 + 2 ) * 16 ) + ( 2 ) + ( 1 ) ];
	n_posix_char line_1[ ( 8 + 1 ) + ( ( 1 + 2 ) * 16 ) + ( 2 ) + ( 1 ) ];

	n_txt t; n_txt_zero( &t ); n_txt_new ( &t );

	size_t i, ii;

	i = ii = 0;
	while( 1 )
	{//break;

		if ( ( i % 16 ) == 0 )
		{
			n_posix_sprintf_literal( line_0, "%08x ", (unsigned int) i / 16 * 16 );
			n_posix_sprintf_literal( line_1, "%8c ",   N_STRING_CHAR_SPACE );

			ii += ( 8 + 1 );
		}

		if ( byte != 0 )
		{

			n_posix_sprintf_literal( &line_0[ ii ], " %02x", p[ i ] );

			if ( n_string_char_is_ascii( p[ i ] ) ) 
			{
				n_posix_sprintf_literal( &line_1[ ii ], "  %c",  p[ i ] );
			} else {
				n_posix_sprintf_literal( &line_1[ ii ], "  %c",  N_STRING_CHAR_DOT );
			}

			ii += ( 1 + 2 );

		}

		if ( ( i % 16 ) == 15 )
		{
			ii = 0;
			n_txt_add( &t, t.sy, line_0 );
			n_txt_add( &t, t.sy, line_1 );
		}


		i++;
		if ( i >= byte ) { break; }
	}


	if ( ( i % 16 ) != 0 )
	{
		n_txt_add( &t, t.sy, line_0 );
		n_txt_add( &t, t.sy, line_1 );
	}


	n_txt_free( txt );
	n_txt_alias( &t, txt );


	// [Needed] : n_win_txtbox

	n_txt_stream( txt );


	n_txt_del( txt, 0 );


	n_memory_free_closed( p );


	return;
}

